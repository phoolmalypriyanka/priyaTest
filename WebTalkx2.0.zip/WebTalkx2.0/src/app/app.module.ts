import { BrowserModule } from '@angular/platform-browser';
import { NgModule, Component } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { VideojsRecordComponent } from './videojs-record/videojs-record.component';
import { HttpClientModule } from '@angular/common/http';

//import { HttpModule } from '@angular/http';

import { HashLocationStrategy, LocationStrategy } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { ArchwizardModule } from 'angular-archwizard';
import { NgMultiSelectDropDownModule } from 'ng-multiselect-dropdown';
import { RouterModule, Routes } from '@angular/router';
import { BsDatepickerModule } from 'ngx-bootstrap/datepicker';
import { CommonModule } from '@angular/common';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
//import { AutocompleteLibModule } from 'angular-ng-autocomplete';
//import { DataTablesModule } from 'angular-datatables';

import { SurveyApplicationComponent } from './SurveyApplication/SurveyApplication.component';
import { SurveyStartComponent } from './SurveyApplication/survey-start/survey-start.component';
import { LoginComponent } from './Login/login.component';
import { SurveyRecordComponent } from './SurveyApplication/survey-record/survey-record.component';
import { SurveyCompleteComponent } from './SurveyApplication/survey-complete/survey-complete.component';
import { IntroVideoComponent } from './SurveyApplication/intro-video/intro-video.component';

import { DashboardComponent } from './SurveyApplication/Dashboard/Dashboard.component';
import { RecordingRequestComponent } from './SurveyApplication/Ask/RecordingRequest/RecordingRequest.component';
import { RecordingComponent } from './SurveyApplication/Record/RecordingComponent/RecordingComponent.component';
import { RequestedByMeComponent } from './SurveyApplication/Record/RequestedByMe/RequestedByMe.component';
import { RecordingsCatalogIRequestedComponent } from './SurveyApplication/Catalog/RecordingsCatalogIRequested/RecordingsCatalogIRequested.component';
import { InboxComponent } from './SurveyApplication/Inbox/Inbox.component';
import { RecordingReviewComponent } from './SurveyApplication/RecordingReview/RecordingReview';
import { ChangePasswordComponent } from './SurveyApplication/Password/ChangePassword/ChangePassword.component';

import { RequestsFromMeComponent } from './SurveyApplication/Record/RequestsFromMe/RequestsFromMe.component';
import { RecordingsCatalogIDidComponent } from './SurveyApplication/Catalog/RecordingsCatalogIDid/RecordingsCatalogIDid.component';
import { RecordingsCatalogForMyReviewComponent } from './SurveyApplication/Catalog/RecordingsCatalogForMyReview/RecordingsCatalogForMyReview.component';
import { MyQuestionsComponent } from './SurveyApplication/Ask/MyQuestions/MyQuestions.component';

import { RegistMsgComponent } from './RegistMsg/RegistMsg.component';
import { SecureURLComponent } from './SecureUrl/SecureUrl.component';
import { TeamMembersComponent } from './SurveyApplication/TeamMembers/TeamMembers.component';

import { SavedRequestsComponent } from './SurveyApplication/Ask/SavedRequests/SavedRequests.component';
import { EditProfileComponent } from './SurveyApplication/EditProfile/EditProfile.component';

import { ConfirmationCodeComponent } from './SurveyApplication/Password/ConfirmationCode/ConfirmationCode.component';
import { ForgotPasswordComponent } from './SurveyApplication/Password/ForgotPassword/ForgotPassword.component';
import { ResetPasswordComponent } from './SurveyApplication/Password/ResetPassword/ResetPassword.component';
import { VendorLineChartComponent } from './Vendor-line-chart/vendor-line-chart.component';
import { FeedbackResponseComponent } from './FeedbackResponse/FeedbackResponse.component';
//import { DragDropModule } from '@angular/cdk/drag-drop';
// Import angular-fusioncharts
import { FusionChartsModule } from 'angular-fusioncharts';
import { NgxSortableModule } from 'ngx-sortable';
// Import FusionCharts library and chart modules
import * as FusionCharts from 'fusioncharts';
import * as Charts from 'fusioncharts/fusioncharts.charts';
import * as FusionTheme from 'fusioncharts/themes/fusioncharts.theme.fusion';
import { SignUpComponent } from './sign-up/sign-up.component';
import { RecordingsCatalogTestComponent } from './SurveyApplication/Catalog/recordings-catalog-test/recordings-catalog-test.component';
import { StaticRatingStarComponent } from './StaticRatingStar/static-rating-star.component';
import { RecordingsCatalogIRequested2Component } from './SurveyApplication/Catalog/recordings-catalog-irequested2/recordings-catalog-irequested2.component';
import { RecordingsCatalogIDid2Component } from './SurveyApplication/Catalog/recordings-catalog-idid2/recordings-catalog-idid2.component';
import { RecordingsCatalogForMyReview2Component } from './SurveyApplication/Catalog/recordings-catalog-for-my-review2/recordings-catalog-for-my-review2.component';

FusionChartsModule.fcRoot(FusionCharts, Charts, FusionTheme);


@NgModule({
  declarations: [
    AppComponent,
    VideojsRecordComponent,
    SurveyApplicationComponent, SurveyStartComponent, LoginComponent, SurveyRecordComponent,
    SurveyCompleteComponent, IntroVideoComponent, DashboardComponent, RecordingComponent,
    InboxComponent, RecordingRequestComponent, RequestedByMeComponent, FeedbackResponseComponent,
    RecordingsCatalogIRequestedComponent, RequestsFromMeComponent,RecordingsCatalogIDidComponent,
    RecordingsCatalogForMyReviewComponent, MyQuestionsComponent,RecordingReviewComponent, TeamMembersComponent,
    ChangePasswordComponent, SavedRequestsComponent, EditProfileComponent, ConfirmationCodeComponent,
    ForgotPasswordComponent, ResetPasswordComponent, SecureURLComponent, RegistMsgComponent, VendorLineChartComponent, SignUpComponent, RecordingsCatalogTestComponent, StaticRatingStarComponent, RecordingsCatalogIRequested2Component, RecordingsCatalogIDid2Component, RecordingsCatalogForMyReview2Component
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    //HttpModule,
    FormsModule,
    ArchwizardModule,
    ReactiveFormsModule, ArchwizardModule,
    CommonModule/*, DataTablesModule*/, FusionChartsModule, BrowserAnimationsModule, NgxSortableModule,
    //AutocompleteLibModule
  ],
  providers: [{ provide: LocationStrategy, useClass: HashLocationStrategy }],
  bootstrap: [AppComponent]
})
export class AppModule { }

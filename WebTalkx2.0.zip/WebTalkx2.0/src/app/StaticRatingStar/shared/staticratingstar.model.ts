export class infopackmodel {
  UserID: number;
  Email: string;
  Message: string;
  SendType: number

  //email: string;
  Name: string;
  ComapanyName:string;
  Location: string;
  SendFor: number;
  Title: string;
}

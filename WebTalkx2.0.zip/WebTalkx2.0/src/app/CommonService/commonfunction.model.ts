export class FiledValue {
  Id: number;
  Value: string; 
}

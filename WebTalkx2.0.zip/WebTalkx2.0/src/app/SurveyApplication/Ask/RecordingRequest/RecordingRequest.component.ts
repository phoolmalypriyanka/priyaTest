import { Component, OnInit, ViewChild } from '@angular/core';
import { FormGroup, NgModel, NgForm } from '@angular/forms';
import { Router } from '@angular/router';
import { HttpErrorResponse } from '@angular/common/http';
import { Title } from '@angular/platform-browser';
import { AppComponent } from '../../../app.component';
import { GlobalVariable } from '../../../globals';
import { SurveyApplicationComponent } from '../../SurveyApplication.component';
import { ActivatedRoute } from '@angular/router';
import { environment } from 'src/environments/environment';
import { HttpClient } from '@angular/common/http';
//import { moveItemInArray, CdkDragDrop } from '@angular/cdk/drag-drop';
import videojs from 'video.js';
import * as RecordRTC from 'recordrtc';

import * as Record from 'videojs-record/dist/videojs.record.js';


@Component({
  selector: 'app-RecordingRequest',
  templateUrl: './RecordingRequest.component.html',
  styleUrls: ['./RecordingRequest.component.css']
})

export class RecordingRequestComponent implements OnInit {

  title: string;
  RecordingTypeValue: string = 'Video';  
  headertext: string = 'Recording Request';  
  SavedQuestionList: any = {};
  form: FormGroup;
  model: any = {};
  documentToUpload: File = null;
  finalizeSelectedQu: any = [];
  
  questionList;
  question_length: number = 0;
  IsRecordingStarted: boolean = false;
  IsRecordingCanceled: boolean = false;

  max_fields = 10; //Maximum allowed input fields 
  LoginUserID: number;
  UserID: number;;
  
  RefRecordingID: number;
  
  checkedListQuestion: any = [];
  prev_type:string;
  favouriteQuestion: [];
  
  reviewerteamlist:any = [];
  grouplist:any = [];

  recordingtype:string;
  q_index:number = 1;
  // index to create unique ID for component
  idx = 'clip1';
  public preview = null;
  private config: any;
  private player: any; 
  private plugin: any;
  record_header:string = 'Record Video';
  TotalTime: any;
  AnswerLimitVal: any;
  recordinglimit_list:any = [];
  submissionlimit_list:any = [];
  candidatedoc:string;
  stepCount:number = 0;
  step_one:boolean = true;
  step_two:boolean = true;
  step_three:boolean = true;
  step_four:boolean = true;
  step_five:boolean = true;
  isdocumentUpload: boolean = false;
  isdocTypeSelected: boolean = false;
  documentToUpload: File = null;
  logoToUpload: File = null;
  jobdescToUpload: File = null;
  candDocToUpload: File = null;
  welcomepagename:string;
  logoname:string;
  jobdescription:string;
  hiringId:number;
  webTalkxtypeId:number;
  webtalkxtype:string;
  selected_type_id:number;
  record_limitid:number;
  submission_limitid:number;
  reviewteam_id:number;
  surveyid:number;
  surveygrouplist:any = [];
  collectorId:number;
  collector_type:string;
  recordingId:number;
  updateForm:boolean = false;
  video_index:number;

  SampQuestion1 = [
    { "name": "Please introduce yourself and what is your relationship and history with the candidate?" },
    { "name": "How do you know the candidate?" },
    { "name": "Please describe the candidate's character, values and social behavior." },
    { "name": "What was one of the most memorable accomplishments since you have known the candidate?" },
    { "name": "Have you witnessed the candidate in any stressful situation - how did he/she react? Please provide an example." },
    { "name": "Would you trust the candidate with large sums of money, children, or fragile individuals?" },
    { "name": "If you think about the candidate, is there anything that stands out? Can you share any accomplishment or situational experience that is most remarkable?" },
    { "name": "How would you describe the candidate’s reliability and dependability?" },
    { "name": "What is your overall opinion of the subject?" },
    { "name": " What are the subject’s strengths and what are areas you feel the subject can improve?" },
  ];

  SampQuestion2 = [
    { "name": "Please introduce yourself and what is your professional relationship to the candidate and how did it begin?" },
    { "name": "How long did you work with the candidate and what positions did you both hold while your worked with the candidate?" },
    { "name": "What were the candidate’s responsibilities while working at your company and how did these responsibilities change over time?" },
    { "name": "If you had the opportunity, would you re-hire this job candidate? Why?" },
    { "name": "What are the candidate’s biggest strengths and weaknesses?" },
    { "name": "What are the candidate’s professional strengths and how were they an asset for the team and your company?" },
    { "name": "Please tell me what it’s like to work with the job candidate." },
    { "name": "What advice would you give to successfully manage the job candidate?" },
    { "name": "Is there anything else you like to share about the candidate that hasn't been asked?" },
    { "name": "What are the most challenging aspects of the role that the candidate held and the work that the candidate did at your company?" },
    { "name": "How would you describe the candidate’s reliability and dependability?" },
    { "name": "What was one of the candidate’s most memorable accomplishments while working with you?" },
    { "name": "What type of work environment do you think the candidate would be most likely to thrive in, and why?" },
    { "name": "Would you recommend this candidate?" },

  ];

  SampQuestion3 = [
    { "name": "Please introduce yourself and what is your relatioship with the candidate." },
    { "name": "How long did the candidate work for you?" },
    { "name": "What were the candidates job duties and responsibilities?" },
    { "name": "How old was the person the candidate cared for?" },
    { "name": "Were you satisfied with the candidates job performance? Why or why not?" },
    { "name": "Did you feel like you were always informed of what was going on while the candidates was caring for patients?" },
    { "name": "Were they always reachable while they were working for you?" },
    { "name": "Were they punctual, and did that continue to be the case the entire time they worked for you?" },
    { "name": "Does this person work well independently?" },
    { "name": "Did this person show initiative?" },
    { "name": "What were some areas in which they could improve?" },
    { "name": "What was your child’s or relative’s (whomever was cared for) feedback about this person?" },
    { "name": "Tell me one of the great things they used to do with your kids or loved one?" },
    { "name": "Did you get the feeling that this person was enthusiastic and happy about doing this job?" },
    { "name": " What did this person do to keep the person or people in their care active? (Talk to them, read stories, play music, go for walks, etc. This will help you get an idea of what the day-to-day activities might look like." },
    { "name": "What was your favorite thing about working with this person?" },
    { "name": "Is there anything we should know as a future potential employer of this person, either personality-wise or compensation-wise or behaviorally?" },
  ];

  SampQuestion4 = [
    { "name": "Please introduce yourself and provide some background on your relationship with the realtor?" },
    { "name": "What was the purpose of hiring a realtor, and did you make your selection?" },
    { "name": "How well did the realtor market your home? Please provide any examples that stood out." },
    { "name": "Did the realtor work alone or was a team involved. Please describe your experience in either situation." },
    { "name": "How well were you kept informed about progress? How satisfied were you with the realtor's communication?" },
    { "name": "Please describe your experience working with the realtor during the stages of listing, showing and closing?" },
    { "name": "On a scale of 1 – 10, with 10 being the highest, how satisfied are you with the realtor?" },
  ];

  SampQuestion5 = [
    { "name": "Please introduce yourself and provide some background on the tenant and the property, incl length of lease agreement and type of property." },
    { "name": "How much was the monthly rent and was rent paid on time and in full?" },
    { "name": "Did the tenant take care of the property? Anything that stood out?" },
    { "name": "How did the tenant communicate with you?" },
    { "name": "On a scale of 1 – 10, with 10 being the highest, how satisfied are you with the tenant?" },
    { "name": "Would you rent to this tenant again?" },
  ];

  SampQuestion6 = [
    { "name": "Please introduce yourself and provide some background on your relationship with the financial advisory, how did you get connected? How long have you been a client?" },
    { "name": "Has the advisor been very clear about explaining how he or she gets paid?" },
    { "name": "Does your advisor have discretionary authority, which allows him or her to invest, transfer or otherwise act on your money without prior consent? Or does the advisor seek your approval and understanding before initiating each and every transaction?" },
    { "name": "How would you rate the level of communication? Do you feel you are adequately educated so you can make informed decisions?" },
    { "name": "Is there anything you would change or wish you could improve in your advisory relationship." },
    { "name": "How would you rate the level of communication? Do you feel you are adequately educated so you can make informed decisions?" },
    { "name": "How satisfied have you been with the performance of the advisor?" },
    { "name": "What additional advice do you have in working with the advisor?" },
    { "name": "On a scale of 1 – 10, with 10 being the highest, how satisfied are you with the advisor?" },

  ];

  SampQuestion7 = [
    { "name": "Please introduce yourself and provide some background on your relationship with contractor?" },
    { "name": "What kind of work did the contractor do for you?" },
    { "name": "How did you select the contractor and did you check credentials?" },
    { "name": " Did you have a clear idea of what the contractor was going to do?" },
    { "name": "Please describe your experience working with the contractor? How well did the contractor respond to questions or change requests and were you satisfied with the results?" },
    { "name": "How satisfied have you been with regards to staying in budget and meeting the timeline?" },
    { "name": "What additional advice do you have in working with contractor?" },
    { "name": "On a scale of 1 – 10, with 10 being the highest, how satisfied are you with the contractor?" },
    { "name": "Would you hire the contractor again?" },
  ];

  SampQuestion8 = [
    { "name": "Please introduce yourself and What is your company’s past and current relationship with service provider?" },
    { "name": "When and why did you decide to contract with service provider? What was your organization hoping to achieve?" },
    { "name": "Please describe the service provider engagement with regards to project scope, team composition onshore and offshore, and roles & responsibilities." },
    { "name": "How long did it take the service provider to complete the engagement?" },
    { "name": "What were your resource requirements for the service provider engagement in terms of people assigned and related time commitment? What tasks were you responsible for completing during the engagement?" },
    { "name": "Did service provider follow a methodology and/or leverage specific accelerators, templates and best practices in support of the project?" },
    { "name": "What was the process to manage scope, time and budget during the project?" },
    { "name": "On a scale of 1 – 10, with 10 being the highest, how satisfied are you with the contractor?" },
    { "name": "How did service provider maintain clear communications and effective project management during the engagement lifecycle - and what could have been done better?" },
    { "name": "Please describe your experience during go live and the subsequent support process? How well did service provider respond to help or issue requests and were you satisfied with the results?" },
    { "name": "How satisfied have you been with service provider with regards to meeting milestones, issuing change orders and changing key personal?" },
    { "name": "How well does the solution perform from a technical and functional perspective vs. your expectations?" },
    { "name": "What significant benefits have you realized since the engagement completion? What has the return on investment (ROI) been so far?" },
    { "name": "How flexible has service provider been in terms of handling challenges and conflict situations on the project? Please provide an example." },
    { "name": "Did service provider properly scope the engagement and understand your objectives, needs and preferences?" },
    { "name": "Are the actual service cost inline with what you planned for in the beginning of the engagement?" },
    { "name": "Would you hire the contractor again?" },
    { "name": "How satisfied are you with the speed of the engagement and did the total time spent meet your initial expectations?" },
    { "name": " Was the team delivering your project the same as proposed during contracting, and did the team meet your expectations in terms of skill, experience and flexibility?" },
    { "name": "What additional advice do you have in working with service provider?" },
    { "name": "If there was one thing you could have changed about service provider in the performance of the engagement, what would it be?" },
    { "name": " One a scale of 1 – 10, with 10 being the highest, how satisfied are you with service provider as your vendor?" },
  ];


  SampQuestion9 = [
    { "name": "Please introduce yourself and when and why did you decide to look for software provided by the vendor? What was your organization hoping to achieve?" },
    { "name": "What other vendor products did you consider and how did you conduct the software selection process?" },
    { "name": " Why did you decide to go with the software vendor and which modules of the vendor's software plaform  incl. software version did you choose to buy?" },
    { "name": "How long has your organization been using the software, with how many users and in which geographies?" },
    { "name": "Please describe the software implementation project with regards to implementation scope, team composition and roles & responsibilities. How long did it take to implement the system?" },
    { "name": " What were your resource requirements for the implementation (e.g. time, people, etc)? What tasks were you responsible for completing during the implementation?" },
    { "name": "How well did the vendor's implementation team understand your industry and your specific business needs?" },
    { "name": "How accurately did the vendor's implementation team translate your requirements into the solution design? How was that achieved?" },
    { "name": "How did the vendor maintain clear communications and effective project management during the implementation lifecycle? What could the vendor have done better?" },
    { "name": "Have you done any custom development or modifications, to enhance the standard functionality of the software? If yes, why and how?" },
    { "name": "How well did the vendor build and test the system? Did you experience any surprises or what could the vendor have done better?" },
    { "name": "How did the software provider team prepare your user communty from a change management and training perspective? What feedback have you gotten from your users?" },
    { "name": "Please describe your experience during go live and the subsequent support process? How well did the vendor respond to help or issue requests and were you satisfied with the results?" },
    { "name": "How satisfied have you been with the software provider with regards to: staying in budget, issuing change orders, meeting milestone and changing key personal?" },
    { "name": "How well does the system perform vs. your expectations - from a technical and functional perspective? Are there any workarounds to use that you did not know about beforehand?" },
    { "name": " How much time, resources and expertise does it take your organisation to manage the software system?" },
    { "name": "What significant benefits have you realized since implementing the system? What has the return on investment (ROI) been so far?" },
    { "name": " What would you do differently with regards to software selection, implementation or support?" },
    { "name": "What additional advice do you have in working with the software provider?" },
    { "name": "If there was one thing you could have changed about the vendor in the performance of the engagement, what would it be?" },
    { "name": "On a scale of 1 – 10, with 10 being the highest, how satisfied are you with the software provider as your vendor?" },
  ];

  constructor(private http: HttpClient, public surveyCmp: SurveyApplicationComponent, private router: Router, private titleService: Title, private appcmp: AppComponent, private route: ActivatedRoute) {
    //Recording request
    this.title = appcmp.title + " | Recording request";
    
    //Added window resize event and perform required operation
    window.onresize = (e) => {
      //Method to set the dialog height as per the window height
      this.resizefilterDialog();
    };

    //this.masterSelected = false;
    this.player = false;
        
    // save reference to plugin (so it initializes)
    this.plugin = Record;

    // video.js configuration
    this.config = {
      controls: true,
      autoplay: false,
      fluid: false,
      loop: false,
      width: 320,
      height: 240,
      bigPlayButton: false,
      controlBar: {
        volumePanel: false
      },
      plugins: {
        record: {
          audio: true,
          video: true,
          debug: true,
          maxLength: 30,
          videoMimeType: "video/mp4"
        }
      }
    };
  }

  ngOnInit() {
    //Added below code to updatee the title
    this.titleService.setTitle(this.title);
    
    this.TotalTime = "00:00:00";

    //On page load method
    this.OnPageLoad();
    this.surveyCmp.showNavigation = true;

    //this.linkdInURL = localStorage.getItem('LinkedIn');
  }
  
  ngAfterViewInit() {
    // ID with which to access the template's video element
    let el = 'video_' + this.idx;

    // setup the player via the unique element ID
    this.player = videojs(document.getElementById(el), this.config, () => {
      console.log('player ready! id:', el);
      
      let pictureInpicture = document.getElementsByClassName('vjs-button vjs-icon-picture-in-picture-start')[0];
      if(pictureInpicture) pictureInpicture.className += '  vjs-hidden';
      
      let vjs_fullscreen = document.getElementsByClassName('vjs-fullscreen-control vjs-control vjs-button')[0];
      if(vjs_fullscreen) vjs_fullscreen.className += '  vjs-hidden';

      // print version information at startup
      var msg = 'Using video.js ' + videojs.VERSION +
        ' with videojs-record ' + videojs.getPluginVersion('record') +
        ' and recordrtc ' + RecordRTC.version;
      videojs.log(msg);
    });

    // device is ready
    this.player.on('deviceReady', () => {
      console.log('device is ready!');
    });

    // user clicked the record button and started recording
    this.player.on('startRecord', () => {
      console.log('started recording!');
    });

    // user completed recording and stream is available
    this.player.on('finishRecord', () => {
      if(!this.IsRecordingCanceled) {
        const formData: FormData = new FormData();
        //formData.append('file', this.player.recordedData, this.player.recordedData.name);
        //console.log('finished recording: ', this.player.recordedData, this.player.recordedData.name);
        /*let q_index = localStorage.getItem("QuestionIndex");
        
        if(this.question_length == Number(q_index)){
          
          //hiding loader after login
          this.appcmp.showLoader = true;
        }*/
        
        let usercode = 'request_'+this.recordingId + '_' + this.video_index;
        var ext =  this.player.recordedData.name.split('.').pop();
        let file_name = usercode +'.'+ ext;
        formData.append('file', this.player.recordedData, file_name);

        let ques_index = this.video_index;

        console.log('Player: ', this.player, file_name);
                        
        //return false;
        return this.http
          .post(`${environment.api}upload`, formData).subscribe(res=>{
            
            let replay_elm = document.getElementsByClassName('replay_'+ques_index)[0];
            if(replay_elm) {
              replay_elm.removeAttribute('disabled');
              replay_elm.setAttribute('extension', ext);
            }

            let status_elm = document.getElementsByClassName('status_'+ques_index)[0];
            if(status_elm) status_elm.innerHTML = 'Recorded';
            /*if(this.question_length == Number(q_index)){
              
              //hiding loader after login
              //this.appcmp.showLoader = false;
              //this.router.navigateByUrl('/SurveyApp/Completed');
            }*/
            //this.preview = `${environment.api}data/file-${this.player.recordedData.name}`
          });
       
          
      } else {
        let video_btn = document.getElementsByClassName('vjs-device-button vjs-control')[0];
        (video_btn as HTMLButtonElement).click();

        this.IsRecordingCanceled = false;
      }
      
    });

    // error handling
    this.player.on('error', (element, error) => {
      console.warn(error);
    });

    this.player.on('deviceError', () => {
      console.error('device error:', this.player.deviceErrorCode);
    });
  }

  // use ngOnDestroy to detach event handlers and remove the player
  ngOnDestroy() {
    if (this.player) {
      this.player.dispose();
      this.player = false;
    }
  }
  
  // Method to load datatable js file.
  public loadDataTable() {
    let body = <HTMLDivElement>document.body;
    let script = document.createElement('script');
    script.innerHTML = '';
    script.src = 'assets/js/demo/datatables-demo.js';
    script.async = true;
    script.defer = true;
    body.appendChild(script);
  }

  //Method to enable the template question section
  enableBtnAndCont(target, createquesbtn, templatequesbtn, create_question_cont, template_question_cont) {
    if(target.classList.contains('btn-primary')) return false;
        
    if(createquesbtn && createquesbtn.classList.contains('btn-primary')){
      createquesbtn.classList.remove('btn-primary');
      
      if(create_question_cont && !create_question_cont.classList.contains('-hidden')){
        create_question_cont.className += ' -hidden';
      }
    } else if(createquesbtn && !createquesbtn.classList.contains('btn-primary')){
      createquesbtn.className += ' btn-primary';
      
      if(create_question_cont && create_question_cont.classList.contains('-hidden')){
        create_question_cont.classList.remove('-hidden');
      }

    }

    if(templatequesbtn && !templatequesbtn.classList.contains('btn-primary')){
      templatequesbtn.className += ' btn-primary';

      if(template_question_cont && template_question_cont.classList.contains('-hidden')){
        template_question_cont.classList.remove('-hidden');
      }
    } else if(templatequesbtn && templatequesbtn.classList.contains('btn-primary')){
      templatequesbtn.classList.remove('btn-primary');

      if(template_question_cont && !template_question_cont.classList.contains('-hidden')){
        template_question_cont.className += ' -hidden';
      }

    }
  }

  //Method to select the webtalkx type
  selectWebtalkxType(element, type) {
    let webtalkx_type = document.getElementsByClassName('webtalkx_type');
    
    if(webtalkx_type) {
      for(let i = 0; i < webtalkx_type.length; i++){
        if(webtalkx_type[i] && webtalkx_type[i].classList.contains('active-block')) {
          webtalkx_type[i].classList.remove('active-block');
          webtalkx_type[i].classList.remove('bg-blue');
        }
      }
    }

    //if selected block is not equal to the previous selected block then reset everything
    if(this.prev_type != type) {
      this.model.HireRecording = null;
      this.model.ReferenceRecording = null;
      this.model.SurveyGroupRecording = null;
      this.model.GeneralRecording = null;

      //If group or project created on second step but we moved back and selected the different block then reset and allow to create new or select existing from dropdown
      this.surveyid = null;
      this.hiringId = null;
      this.step_two = true;
      this.step_one = true;
    }
    
    if(element && !element.classList.contains('active-block')) element.className += ' active-block bg-blue';

    this.prev_type = type;
    this.webtalkxtype = type;

    if(type == 'Hiring') this.selected_type_id = 1;
    if(type == 'Reference') this.selected_type_id = 2;
    if(type == 'Survey') this.selected_type_id = 3;
    if(type == 'Offline Meeting') this.selected_type_id = 4;

    //Now get the group or project list
    this.getGroupProjectList(type);

  }

  //Method to select the recording type
  selectRecordingType(record_type:string){
    this.recordingtype = record_type;

    if(record_type == 'Group Recording'){
      //Now to get the reviewer team list
      this.getReviewerTeamList();
      
      //Now get the submission limit list
      this.getSubmissionList();
      
      //Now get the submission limit list
      this.getRecordingList();
    }
    
  }

  //Method to select group survey
  selectSurveyRecordingType(record_type:string){
    this.recordingtype = "Group Survey";

  }

  //Method to select collector
  selectCollector(target, name) {
    this.collector_type = name;
    let collector_container = document.querySelectorAll('.collector-content-container');

    if(collector_container.length > 0) {
      for(let i = 0; i < collector_container.length; i++){
        if(collector_container[i] && collector_container[i].classList.contains('active-block')) {
          collector_container[i].classList.remove('active-block');
          collector_container[i].classList.remove('bg-blue');
        }
      }
    }
    if(target && !target.classList.contains('active-block')) target.className += ' active-block bg-blue';

    if(name){
      let weblink_cont = document.getElementsByClassName('weblink_cont')[0];
      let socialmedia_cont = document.getElementsByClassName('socialmedia_cont')[0];
      let manualentry_cont = document.getElementsByClassName('manualentry_cont')[0];
      let api_cont = document.getElementsByClassName('api_cont')[0];

      if(name.trim() == 'Weblink') {
        if(weblink_cont && weblink_cont.classList.contains('-hidden')) weblink_cont.classList.remove('-hidden');
        if(socialmedia_cont && !socialmedia_cont.classList.contains('-hidden')) socialmedia_cont.className += ' -hidden';
        if(manualentry_cont && !manualentry_cont.classList.contains('-hidden')) manualentry_cont.className += ' -hidden';
        if(api_cont && !api_cont.classList.contains('-hidden')) api_cont.className += ' -hidden';
      
      } else if(name.trim() == 'Social') {
        if(weblink_cont && !weblink_cont.classList.contains('-hidden')) weblink_cont.className += ' -hidden';
        if(socialmedia_cont && socialmedia_cont.classList.contains('-hidden')) socialmedia_cont.classList.remove('-hidden');
        if(manualentry_cont && !manualentry_cont.classList.contains('-hidden')) manualentry_cont.className += ' -hidden';
        if(api_cont && !api_cont.classList.contains('-hidden')) api_cont.className += ' -hidden';
      
      } else if(name.trim() == 'Manual') {
        if(weblink_cont && !weblink_cont.classList.contains('-hidden')) weblink_cont.className += ' -hidden';
        if(manualentry_cont && manualentry_cont.classList.contains('-hidden')) manualentry_cont.classList.remove('-hidden');
        if(socialmedia_cont && !socialmedia_cont.classList.contains('-hidden')) socialmedia_cont.className += ' -hidden';
        if(api_cont && !api_cont.classList.contains('-hidden')) api_cont.className += ' -hidden';
      
      } else if(name.trim() == 'API') {
        if(weblink_cont && !weblink_cont.classList.contains('-hidden')) weblink_cont.className += ' -hidden';
        if(manualentry_cont && !manualentry_cont.classList.contains('-hidden')) manualentry_cont.className += ' -hidden';
        if(socialmedia_cont && !socialmedia_cont.classList.contains('-hidden')) socialmedia_cont.className += ' -hidden';
        if(api_cont && api_cont.classList.contains('-hidden')) api_cont.classList.remove('-hidden');
      }
       
    }
  }

  //Method to execute on page load
  OnPageLoad() {
    //this.model.RecordingType = null;
    this.model.ReplayConsent = null;
    this.model.QuestionnaireCategory = null;
    this.model.ExistingGroup = null;
    this.model.RecordingLimit = null;
    this.model.ReviewTeam = null;
    this.model.AnswerLimit = null;
    this.model.SubmissionLimit = null;
    this.model.SurveyReviewTeam = null;
    this.model.HiringRecordingLimit = null;
    this.model.HiringReviewTeam = null;

    //this.model.SurveyGroupRecording = 'Group Recording';
    this.UserID = Number(localStorage.getItem('LoginUserID'));

    this.route.params.subscribe(routeParams => {
      //console.log('routeParams 1', routeParams);
      //console.log('UserID', routeParams.id);
      if (routeParams && routeParams.id) {
        //localStorage.setItem('RefRecordingID', routeParams.id);
        let rid = routeParams.id;

        this.RefRecordingID = rid;

        //Now getting recording details
        //if (this.RefRecordingID) this.getRecordingDetails(this.RefRecordingID);
      }
    });
    
    //Method to set the dialog height as per the window height
    this.resizefilterDialog();

    //Method to get the my question list
    if (this.RefRecordingID) this.GetMyQuestions(this.RefRecordingID);

    //Method to get the recording list
    this.GetMySavedQuestionsByUser()

    //Now create 3 text box for question
    this.createQuestionTextBox();

  }

  //Method to create only 3 question text box
  createQuestionTextBox() {
    //It will create only if no ref recording id available else not
    if (!this.RefRecordingID) {
      setTimeout(function () {
        // let add_fields = document.getElementsByClassName('add_fields')[0];
        // if (add_fields) {
        //   (add_fields as HTMLButtonElement).click();
        //   (add_fields as HTMLButtonElement).click();
        // }
        var addNewQuestions = document.getElementsByClassName('addNewQuestions')[0];

        if(addNewQuestions) {
          (addNewQuestions as HTMLButtonElement).click();
          (addNewQuestions as HTMLButtonElement).click();
          (addNewQuestions as HTMLButtonElement).click();
        }
      }, 500);
    }
  }

  // Method for get all recording details by ID
  /*getRecordingDetails(ids: number) {

    let recObj: any = {};
    recObj.RefRecordingID = ids;
    this.appcmp.showLoader = true;
    this.appcmp.loadermessage = 'Please wait, fetching recording details...';
    
    return this.http
    .post(`${environment.domainApi}I2BRecordingRequest/GetRecordingRequestByID`, recObj).subscribe(res=>{
      if (res[0]['ResponseStatus'] == 'Success') {
        this.model = {
          Instructions: res[0]['Instructions'],
          ReplayConsent: (res[0]['ReplayConsent'] == 'Platform') ? true : false,
          GiverFirstName: res[0]['GiverFirstName'],
          GiverSecondName: res[0]['GiverSecondName'],
          GiverEmailID: res[0]['GiverEmailID'],
          GiverLinkedIn: res[0]['GiverLinkedIn'],
          RecordingTitle: res[0]['RecordingTitle'],
          Purpose: res[0]['Purpose'],
          RelationShipType: res[0]['RelationShipType'],
          WorkTogetherAt: res[0]['WorkTogetherAt'],
          WorkStartDate: res[0]['WorkStartDate'],
          WorkEndDate: res[0]['WorkEndDate'],
          GiverJobTitle: res[0]['GiverJobTitle'],
          OwnJobTitle: res[0]['OwnJobTitle'],
          QuestionnaireCategory: res[0]['QuestionnaireCategory'],
          IsDraft: res[0]['IsDraft'],
          Title: res[0]['Title']
        }

        if (res[0]['GiverLinkedIn'] && (res[0]['GiverLinkedIn'].indexOf('https') == -1 || res[0]['GiverLinkedIn'].indexOf('http') == -1)) {
          this.model.GiverLinkedIn = 'https://' + res[0]['GiverLinkedIn'];
        }

        //this.savebtn = 'Update Draft';
        //this.IsUpdate = true;
        //hiding loader after login
        this.appcmp.showLoader = false;

        localStorage.removeItem('RefRecordingID');
      }
    });
  }*/

  onSubmit(form: NgModel) {

    if(form && form.value) {
      this.updateForm = true;
      this.insertAndUpdateFormData(form, "Y");
                
    }

    //if (this.hiringId || this.surveyid) {
    /*
    if (form && form.value) {
      let recObj: any = {};
      
      if (this.hiringId) form.value.HiringID = this.hiringId;
      if (this.surveyid) form.value.SurveyID = this.surveyid;

      form.value.HiringWebTalkxTypeID = this.webTalkxtypeId;
      form.value.ProjectName = form.value.HiringProjectName;
      form.value.JobDescription = this.jobdescription || form.value.descriptionfile;
      form.value.HiringStartDate = form.value.HiringStartDate || "2021-01-01";
      form.value.HiringEndDate = form.value.HiringEndDate || "2021-02-02";
      form.value.Organisation = form.value.HiringOrganization;
      form.value.Manager = form.value.HiringManager;
      form.value.HiringReviewTeamID = this.reviewteam_id || form.value.HiringReviewTeam;
      form.value.HiringRecordingLimitID = this.record_limitid || form.value.HiringRecordingLimit;
      form.value.HiringWelcomeMessage = form.value.WelcomeMessage;
      form.value.HiringDescription = form.value.Description;
      form.value.EmailID = form.value.HiringEmailId;
      form.value.FirstName = form.value.FirstName;
      form.value.LastName = form.value.LastName;
      form.value.PhoneNumber = form.value.PhoneNumber;
      form.value.LinkedIn = form.value.LinkedinProfileLink;
      form.value.Documents = this.candidatedoc || form.value.candidatedocument;
      form.value.SurveyID = this.surveyid;
      form.value.SurveyWebTalkxTypeID = this.webTalkxtypeId;
      form.value.KeepSurveyAnonymous = form.value.IsSurveyAnonymous;
      form.value.SurveyStartDate = form.value.SurveyStartDate || "2021-01-01";
      form.value.SurveyEndDate = form.value.SurveyEndDate || "2021-01-02";
      form.value.SurveySubmissionLimitID = form.value.SubmissionLimit;
      form.value.SurveyTitle = form.value.SurveyTitle;
      form.value.SurveyWelcomeMessage = form.value.WelcomeMessage;
      form.value.SurveyDescription = form.value.Description;
      form.value.SponsorMessageRequired = form.value.IsIntroMessage;
      form.value.SurveyReviewTeamID = this.reviewteam_id || form.value.SurveyReviewTeam;
      form.value.SurveyIndividualRecordingLimitID = this.record_limitid || form.value.RecordingLimit;
      form.value.CustomWelcomePage = this.welcomepagename || form.value.CustomWelcome;
      form.value.CollectorType = this.collector_type;
      form.value.WelcomePageRequired = form.value.IsIntroMessage;
      form.value.FinalStatus = 'Open';
      form.value.AuthorID = 1;

            
      this.appcmp.showLoader = true;
      this.appcmp.loadermessage = 'Please wait, recording request is being send...';
      console.log("formn", form.value);

      //return false;
            
      return this.http
      //.post(`${environment.domainStageApi}FinalSubmission/UpdateStatusForFinalSubmission`, form.value).subscribe(res=>{
        .post(`${environment.domainStageApi}FinalSubmission/InsertFinalSubmissionDetails`, form.value).subscribe(res=>{
          let data = Object.keys(res).length;
          if (data && res[0]['ResponseStatus'] == 'Success') {
          //this.step_one = false;
          this.recordingId = res[0]['ID'];
          
          //Method to insert the questions
          this.InsertRecordingQuestion(this.recordingId);

          //Now redirect on request by me page
          this.router.navigateByUrl('/I2BApplication/RequestsByMe');

          //hiding loader after login
          this.appcmp.showLoader = false;
          
        }
      });
    }
    */
  }

  //Method to insert and update the recording details
  insertAndUpdateFormData(form, mode){
    
    if (form && form.value) {
            
      form.value.HiringID = this.hiringId || null;
      form.value.SurveyID = this.surveyid || null;
      form.value.HiringWebTalkxTypeID = this.selected_type_id || null;
      form.value.ProjectName = form.value.HiringProjectName || null;
      form.value.JobDescription = this.jobdescription || form.value.descriptionfile || null;
      form.value.HiringStartDate = form.value.HiringStartDate || "2021-01-01" || null;
      form.value.HiringEndDate = form.value.HiringEndDate || "2021-02-02" || null;
      form.value.Organisation = form.value.HiringOrganization || null;
      form.value.Manager = form.value.HiringManager || null;
      form.value.HiringReviewTeamID = this.reviewteam_id || form.value.HiringReviewTeam || null;
      form.value.HiringRecordingLimitID = this.record_limitid || form.value.HiringRecordingLimit || null;
      form.value.HiringWelcomeMessage = form.value.WelcomeMessage || null;
      form.value.HiringDescription = form.value.Description || null;
      form.value.EmailID = form.value.HiringEmailId || null;
      form.value.FirstName = form.value.FirstName || null;
      form.value.LastName = form.value.LastName || null;
      form.value.PhoneNumber = form.value.PhoneNumber || null;
      form.value.LinkedIn = form.value.LinkedinProfileLink || null;
      form.value.Documents = this.candidatedoc || form.value.candidatedocument || null;
      form.value.SurveyWebTalkxTypeID = this.selected_type_id || null;
      form.value.KeepSurveyAnonymous = form.value.IsSurveyAnonymous || null;
      form.value.SurveyStartDate = form.value.SurveyStartDate || "2021-01-01" || null;
      form.value.SurveyEndDate = form.value.SurveyEndDate || "2021-01-02" || null;
      form.value.SurveySubmissionLimitID = form.value.SubmissionLimit || null;
      form.value.SurveyTitle = form.value.SurveyTitle || null;
      form.value.SurveyWelcomeMessage = form.value.WelcomeMessage || null;
      form.value.SurveyDescription = form.value.Description || null;
      form.value.SponsorMessageRequired = form.value.IsIntroMessage || null;
      form.value.SurveyReviewTeamID = this.reviewteam_id || form.value.SurveyReviewTeam || null;
      form.value.SurveyIndividualRecordingLimitID = this.record_limitid || form.value.RecordingLimit || null;
      form.value.CustomWelcomePage = this.welcomepagename || form.value.CustomWelcome || null;
      form.value.CollectorType = this.collector_type || null;
      form.value.WelcomePageRequired = form.value.IsIntroMessage || null;
      form.value.AuthorID = this.UserID;

      //return false;
      
      if(mode == 'Y' && this.recordingId) {

        form.value.ID = this.recordingId;
        this.appcmp.showLoader = true;

        if(this.updateForm) {
          form.value.FinalStatus = 'Open' || null;
          this.appcmp.loadermessage = 'Please wait, recording request is being send...';
        } else {
          form.value.FinalStatus = 'Draft' || null;
          //this.appcmp.loadermessage = 'Please wait, recording request is being updated...';
          //hiding loader after login
          this.appcmp.showLoader = false;
        }
                
        //console.log("formn", form.value);
        let formObj:any = {};
        formObj = form.value;

        return this.http
        .put(`${environment.domainStageApi}FinalSubmission/UpdateFinalSubmissionDetails`, form.value).subscribe(res=>{
          //FinalSubmission/UpdateStatusForFinalSubmissionWebTalkx
            let data = Object.keys(res).length;
            if (data && res[0]['ResponseStatus'] == 'Success') {
            //this.step_one = false;
            //]this.recordingId = res[0]['ID'];
            
            //Now if update form is true means final submission
            if(this.updateForm){
              this.updateForm = false;
            
              //Method to insert the questions
              this.InsertRecordingQuestion(this.recordingId);
              
              //call to create the giver
              this.giverCreation(formObj, this.recordingId);
            }
            
            //hiding loader after login
            //this.appcmp.showLoader = false;
          }
        });
      } else {
        form.value.FinalStatus = 'Draft' || null;
        
        //this.appcmp.showLoader = true;
        //this.appcmp.loadermessage = 'Please wait, recording request is being saved...';
        //console.log("formn", form.value);

        return this.http
          .post(`${environment.domainStageApi}FinalSubmission/InsertFinalSubmissionDetails`, form.value).subscribe(res=>{
            let data = Object.keys(res).length;
            if (data && res[0]['ResponseStatus'] == 'Success') {
            //this.step_one = false;
            this.recordingId = res[0]['ID'];
            
            //Method to insert the questions
            //this.InsertRecordingQuestion(this.recordingId);

            //Now redirect on request by me page
            //this.router.navigateByUrl('/I2BApplication/RequestsByMe');

            //hiding loader after login
            //this.appcmp.showLoader = false;
          }
        });
      }
    }
  }

  //method to save the giver
  giverCreation(giverObj, refRequestId) {
    //this.appcmp.showLoader = true;

    const giverData = {
      FirstName: giverObj.FirstName,
      LastName: giverObj.LastName,
      EmailID: giverObj.HiringEmailId,
      LinkedIn: giverObj.LinkedinProfileLink || null,
      UserID: giverObj.AutherID,
      RefRecordingID: refRequestId,
      Instructions: giverObj.WelcomeMessage
    }

    return this.http
    .post(`${environment.domainApi}I2B_Users/InsertGiverCreation`, giverData).subscribe(res=>{
      
      let data = Object.keys(res).length;
      if (data && res[0]['ResponseStatus'] == 'Success') {
        
        //Now redirect on request by me page
        this.router.navigateByUrl('/I2BApplication/RequestsByMe');
        
        //hiding loader after started
        this.appcmp.showLoader = false;

        //this._notificationservice.success("Recording Request has been saved.");
      } else {

        //hiding loader after started
        this.appcmp.showLoader = false;

        //this._notificationservice.error(GlobalVariable.TechnicalError);
      }
    });
  }


  //Method to identify the selcted tab
  enableTab(tab, tabcontent) {
    let target, t_attr;

    if (tab) t_attr = tab.getAttribute('href');

    if (t_attr == '#AllQuestions') {


    } else if (t_attr == '#FavQuestions') {
      this.GetMySavedQuestionsByUser(true);

    }
  }

  //Method to update the request as draft
  saveRequestAsDraft(refRequestId) {

    let reqObj: any = {};
    reqObj.RefRecordingID = refRequestId;
    reqObj.RecordingStatus = 'Draft';
    
    return this.http
    .put(`${environment.domainApi}I2BRecordingRequest/UpdateRecordingStatus`, reqObj).subscribe(res=>{
      
      let data = Object.keys(res).length;
      if (data && res[0]['ResponseStatus'] == 'Success') {
        //this.router.navigateByUrl('/I2BApplication/OpenReferenceRequests');
        this.router.navigateByUrl('/I2BApplication/RequestsByMe');

        //hiding loader after started
        this.appcmp.showLoader = false;

        //this._notificationservice.success("Recording Request has been saved.");
      } else {

        //hiding loader after started
        this.appcmp.showLoader = false;

        //this._notificationservice.error(GlobalVariable.TechnicalError);
      }
    });

  }

  //Method to insert the question
  InsertRecordingQuestion(id) {

    if (id) {

      let ques_Obj: any = {}, i = 0;
      var selected_question = document.querySelectorAll('.selected_question');
      var answer_limit = document.querySelectorAll('.AnswerLimit');
      
      //if (Object.keys(this.checkedListBookmark).length > 0) {
      //for (let Bookmark of this.checkedListBookmark) {
      if (selected_question.length > 0) {
        for (let j = 0; j < selected_question.length; j++) {
          let value, q_id, answer_limit_val;

          if (selected_question[j]) {
            if (selected_question[j].nodeName == 'TEXTAREA' && (selected_question[j] as HTMLTextAreaElement).value && (selected_question[j] as HTMLTextAreaElement).value.trim()) {
              if(answer_limit && answer_limit[j]) {
                answer_limit_val = (answer_limit[j] as HTMLSelectElement).value;
              }
              /*if (sort_question[i] && (sort_question[i] as HTMLElement).innerText && (sort_question[i] as HTMLElement).innerText.trim()) {
                value = (sort_question[i] as HTMLElement).innerText.trim();*/
              //console.log((selected_question[j] as HTMLTextAreaElement).value);

              let isDisabled = (selected_question[j] as HTMLTextAreaElement).hasAttribute('disabled')
              //console.log(a.hasAttribute('disabled'));
              if(isDisabled) {
                value = j + 1;
              } else {
                value = (selected_question[j] as HTMLTextAreaElement).value;
              }
              
              q_id = selected_question[j].getAttribute('question_id');

              ques_Obj.RefRecordingID = id;
              ques_Obj.QuestionText = value;
              ques_Obj.QuestionOrder = j + 1;
              ques_Obj.AnswerLimit = answer_limit_val ? answer_limit_val.trim() : '';
              ques_Obj.RecordQuestion = isDisabled;

              if (q_id) {
                ques_Obj.RecordingQuestionID = q_id;
                //Method to update the question
                this.updateOldQuestion(ques_Obj);
              } else {
                //console.log("ques_Obj", ques_Obj);
                //Method to insert the question
                this.insertNewQuestion(ques_Obj);
              }

            }
          }

        }
      }

    }
  }

  //Method to insert the question
  insertNewQuestion(ques_Obj) {
    
    return this.http
    .post(`${environment.domainApi}I2BRecordingRequest/InsertRecordingQuestions`, ques_Obj).subscribe(res=>{
      
      let data = Object.keys(res).length;
      if (data && res[0]['ResponseStatus'] == 'Success') {

        //hiding loader after started
        //this.appcmp.showLoader = false;

        //this._notificationservice.success("Recording question has been inserted.");
      } else {

        //hiding loader after started
        //this.appcmp.showLoader = false;

        //this._notificationservice.error(GlobalVariable.TechnicalError);
      }
    });
  }

  //Method to update the old question
  updateOldQuestion(ques_Obj) {
    
    return this.http
    .put(`${environment.domainApi}I2BRecordingRequest/UpdateRecordingRequestQuestions`, ques_Obj).subscribe(res=>{
      
      let data = Object.keys(res).length;
      if (data && res[0]['ResponseStatus'] == 'Success') {

        //hiding loader after started
        //this.appcmp.showLoader = false;

        //this._notificationservice.success("Recording question has been inserted.");
      } else {

        //hiding loader after started
        //this.appcmp.showLoader = false;

        //this._notificationservice.error(GlobalVariable.TechnicalError);
      }
    });
  }

  //Method to get the group or project list
  getGroupProjectList(type) {

    let obj:any = {};
    obj.WebtalkxType = type;
    obj.UserId = this.UserID;

    if(type == 'Survey') {
      return this.http
      .get(`${environment.domainStageApi}Survey/GetSurveyDetailsByType?WebTalkxType=`+type).subscribe(res=>{
        let data = Object.keys(res).length;
        if (data && res[0]['ResponseStatus'] == 'Success') {
          this.surveygrouplist = res;
        } else {
          this.surveygrouplist = [];
          this.model.ExistingGroup = null;
        }
      });
    } else {
      
      return this.http
      .get(`${environment.domainStageApi}Hiring/GetProjectNames?WebTalkxType=`+type).subscribe(res=>{
        let data = Object.keys(res).length;
        if (data && res[0]['ResponseStatus'] == 'Success') {
          this.grouplist = res;
        } else {
          this.grouplist = [];
          this.model.ExistingGroup = null;
        }
      });
    }

  }
  
  //Method to get the reviewer team list
  getReviewerTeamList() {

    return this.http
    .get(`${environment.domainStageApi}ReviewTeam/GetHiringReviewTeam`).subscribe(res=>{
      let data = Object.keys(res).length;
      if (data && res[0]['ResponseStatus'] == 'Success') {
        this.reviewerteamlist = res;
      } else {
        this.reviewerteamlist = [];
      }
    });
  }
  
  //Now get the submission limit list
  getSubmissionList() {
    
    return this.http
    .get(`${environment.domainStageApi}HiringRecordingLimit/GetHiringRecordingLimit`).subscribe(res=>{
      let data = Object.keys(res).length;
      if (data && res[0]['ResponseStatus'] == 'Success') {
        this.submissionlimit_list = res;
      } else {
        this.submissionlimit_list = [];
      }
    });
  }
  
  //Now get the recording limit list
  getRecordingList() {
    
    return this.http
    .get(`${environment.domainStageApi}IndividualRecordingLimit/GetIndividualRecordingLimit`).subscribe(res=>{
      let data = Object.keys(res).length;
      if (data && res[0]['ResponseStatus'] == 'Success') {
        this.recordinglimit_list = res;
      } else {
        this.recordinglimit_list = [];
      }
    });
  }

  //Method to reset the field value. only those field's value will reset on which user existing.
  HeaderOnSteps(model: any, stepcount: number, btn_name) {
        
    if (stepcount == 1) {
      this.headertext = 'Recording Request';

    } else if (stepcount == 2) {
      this.headertext = 'Add Survey Collector';

    } else if (stepcount == 3) {

      if(this.prev_type == 'Hiring') this.headertext = 'Hiring';
      else if(this.prev_type == 'Reference') this.headertext = 'Reference';
      else if(this.prev_type == 'Offline') this.headertext = 'Offline';
      else if(this.prev_type == 'Survey') {
        //Now to get the reviewer team list
        this.getReviewerTeamList();
        
        //Now get the submission limit list
        this.getSubmissionList();
        
        //Now get the recording limit list
        this.getRecordingList();

        this.headertext = 'Survey';
        this.recordingtype = "Group Survey";
      }
      
      //this.stepCount
      //Now saving the first step
      if((!this.step_one && this.webTalkxtypeId && btn_name == 'Next')) {
        //this.firstStepUpdate(model);
      } else if(this.step_one) {
        //this.firstStepSave(model);
      }

    } else if (stepcount == 4) {
      this.headertext = 'Add Questions';
      this.stepCount++;

      if(this.stepCount == 1){
        //var addNewQuestions = document.getElementsByClassName('addNewQuestions')[0];

        //if(addNewQuestions) {
          //(addNewQuestions as HTMLButtonElement).click();
          //(addNewQuestions as HTMLButtonElement).click();
          //(addNewQuestions as HTMLButtonElement).click();
        //}
      }
            
      //Now saving the second step
      if((!this.step_two && (this.hiringId || this.surveyid) && btn_name == 'Next')) {
        this.secondStepUpdate(model);
      } else if(this.step_two) {
        this.secondStepSave(model);
      }
            
      this.stepCount++;

      //this.saveDraft = false;
      //Now darw the selected question
      this.drawSelectedQuestion();

      let video_btn = document.getElementsByClassName('vjs-device-button vjs-control')[0];
      (video_btn as HTMLButtonElement).click();

    } else if (stepcount == 5){
      this.headertext = 'Welcome Message';

      //Now darw the selected question
      this.drawSelectedQuestion();
           
      //Now saving the second step
      if((!this.step_four && this.collectorId && btn_name == 'Next')) {
        //this.fourthStepUpdate(model);
      } else if(this.step_two) {
        //this.fourthStepSave(model);
      }

    } else if (stepcount == 6){
      this.model.SurveyGroupRecording = 'Group Recording';
      this.headertext = 'Summary';
    }
  }

  //Method to select the group or project from dropdown
  selectGroupOrProject(e, type) {
    let target, index, targetid, val;

    target = (e && e.target) ? e.target : null;
    index = (target) ? target.selectedIndex : null;
    targetid = Number(target.options[index].id);
    val = target.value;

    console.log("aa", target, index, targetid, val);

    //getting next button to move forward after selecting value from dropdown
    let gostep_second = document.getElementsByClassName('gostep_second')[0];
    if(gostep_second) (gostep_second as HTMLButtonElement).click();
    
    // Method to get the details based on project name
    this.getProjectDetails(val, type);

  }

  //Method to select the submission limit from dropdown
  selectSubmissionLimit(e, submissionLimit) {
    let target, index, val;

    target = (e && e.target) ? e.target : null;
    index = (target) ? target.selectedIndex : null;
    this.submission_limitid = Number(target.options[index].id);
    val = target.value;
  }
  
  //Method to select the submission limit from dropdown
  selectRecordingLimit(e, recordLimit) {
    let target, index, val;

    target = (e && e.target) ? e.target : null;
    index = (target) ? target.selectedIndex : null;
    this.record_limitid = Number(target.options[index].id);
    val = target.value;
  }
  
  //Method to select the submission limit from dropdown
  selectReviewTeam(e, recordLimit) {
    let target, index, val;

    target = (e && e.target) ? e.target : null;
    index = (target) ? target.selectedIndex : null;
    this.reviewteam_id = Number(target.options[index].id);
    val = target.value;
  }
    
  // Method to get the details based on project name
  getProjectDetails(val, type) {

    if(type == 'Survey') {
      
      this.appcmp.showLoader = true;
      this.appcmp.loadermessage = 'Please wait, fetching group or project details...';
      
      return this.http
      .get(`${environment.domainStageApi}Survey/GetSurveyDetailsByTypeAndProject?WebTalkxType=`+this.webtalkxtype+`&ProjectName=`+val).subscribe(res=>{
        let data = Object.keys(res).length;
        if (data && res[0]['ResponseStatus'] == 'Success') {
          console.log("res", res);

          this.model = {
            SurveyTitle: res[0]['SurveyTitle'],
            KeepSurveyAnonymous: res[0]['IsSurveyAnonymous'],
            SurveyStartDate: res[0]['SurveyStartDate'],
            SurveyEndDate: res[0]['SurveyEndDate'],
            SurveySubmissionLimit: res[0]['SubmissionLimit'],
            WelcomeMessage: res[0]['WelcomeMessage'],
            Description: res[0]['Description'],
            IsIntroMessage: res[0]['SponsorMessageRequired'],
            UploadLogo: res[0]['UploadLogo'],
            SurveyReviewTeam: res[0]['SurveyReviewTeam'],
            CustomWelcomePage: res[0]['CustomWelcomePage'],
            IndividualRecordingLimit: res[0]['RecordingLimit']
          }
          this.logoUpload = res[0]['UploadLogo'];
          this.welcomepagename = res[0]['CustomWelcomePage'];
          this.surveyid = res[0]['SurveyID'];
                
          //hiding loader after login
          this.appcmp.showLoader = false;
          
        } else {
          
          //hiding loader after login
          this.appcmp.showLoader = false;
        }
      });
    } else {
      
      this.appcmp.showLoader = true;
      this.appcmp.loadermessage = 'Please wait, fetching group or project details...';
      
      return this.http
      .get(`${environment.domainStageApi}Hiring/GetHiringDetailsByProjectNameAndType?WebTalkxType=`+this.webtalkxtype+`&ProjectName=`+val).subscribe(res=>{
        let data = Object.keys(res).length;
        if (data && res[0]['ResponseStatus'] == 'Success') {
          console.log("res", res);

          /*this.model = {
            HiringProjectName: res[0]['ProjectName'],
            JobDescription: res[0]['JobDescription'],
            HiringStartDate: res[0]['HiringStartDate'],
            HiringEndDate: res[0]['HiringEndDate'],
            HiringOrganization: res[0]['Organisation'],
            Manager: res[0]['Manager'],
            HiringReviewTeam: res[0]['ReviewTeam'],
            WelcomeMessage: res[0]['WelcomeMessage'],
            Description: res[0]['Description'],
            HiringEmailId: res[0]['EmailID'],
            FirstName: res[0]['FirstName'],
            LastName: res[0]['LastName'],
            HiringRecordingLimit: res[0]['RecordingLimit'],
            PhoneNumber: res[0]['PhoneNumber'],
            LinkedinProfileLink: res[0]['LinkedinProfileLink'],
            Documents: res[0]['Documents'],
            IsIntroMessage: res[0]['SponsorMessageRequired']
          }*/

          this.candidatedoc = res[0]['Documents'];
          this.jobdescription = res[0]['JobDescription'];
          this.hiringId = res[0]['HiringID'];
          //debugger;
          /*this.model.HireRecording = null;
          this.model.ReferenceRecording = null;
          this.model.SurveyGroupRecording = null;
          this.model.GeneralRecording = null;*/
          
          //hiding loader after login
          this.appcmp.showLoader = false;
          
        }
      });
    }

  }

  // Method to save the first step
  firstStepSave(form) {

    let recObj: any = {};
    recObj.WebTalkxTypeName = this.selected_type_id;
    recObj.GroupRecording = this.recordingtype;
    recObj.AuthorID = this.UserID;

    if(this.hiringId) form.value.HiringID = this.hiringId;
    if(this.surveyid) form.value.SurveyID = this.surveyid;

    form.value.HiringWebTalkxTypeID = this.selected_type_id;
    form.value.ProjectName = form.value.HiringProjectName;
    form.value.JobDescription = this.jobdescription || form.value.descriptionfile;
    form.value.HiringStartDate = form.value.HiringStartDate || "2021-01-01";
    form.value.HiringEndDate = form.value.HiringEndDate || "2021-02-02";
    form.value.Organisation = form.value.HiringOrganization;
    form.value.Manager = form.value.HiringManager;
    form.value.HiringReviewTeamID = this.reviewteam_id || form.value.HiringReviewTeam;
    form.value.HiringRecordingLimitID = this.record_limitid || form.value.HiringRecordingLimit;
    form.value.HiringWelcomeMessage = form.value.WelcomeMessage;
    form.value.HiringDescription = form.value.Description;
    form.value.EmailID = form.value.HiringEmailId;
    form.value.FirstName = form.value.FirstName;
    form.value.LastName = form.value.LastName;
    form.value.PhoneNumber = form.value.PhoneNumber;
    form.value.LinkedIn = form.value.LinkedinProfileLink;
    form.value.Documents = this.candidatedoc || form.value.candidatedocument;
    form.value.SurveyID = this.surveyid;
    form.value.SurveyWebTalkxTypeID = this.selected_type_id;
    form.value.KeepSurveyAnonymous = form.value.IsSurveyAnonymous;
    form.value.SurveyStartDate = form.value.SurveyStartDate || "2021-01-01";
    form.value.SurveyEndDate = form.value.SurveyEndDate || "2021-01-02";
    form.value.SurveySubmissionLimitID = form.value.SubmissionLimit;
    form.value.SurveyTitle = form.value.SurveyTitle;
    form.value.SurveyWelcomeMessage = form.value.WelcomeMessage;
    form.value.SurveyDescription = form.value.Description;
    form.value.SponsorMessageRequired = form.value.IsIntroMessage;
    form.value.SurveyReviewTeamID = this.reviewteam_id || form.value.SurveyReviewTeam;
    form.value.SurveyIndividualRecordingLimitID = this.record_limitid || form.value.RecordingLimit;
    form.value.CustomWelcomePage = this.welcomepagename || form.value.CustomWelcome;
    form.value.CollectorType = this.collector_type;
    form.value.WelcomePageRequired = form.value.IsIntroMessage;
    form.value.FinalStatus = 'Draft';
    form.value.AuthorID = this.UserID;

    this.appcmp.showLoader = true;
    this.appcmp.loadermessage = 'Please wait, saving recording details...';
    
    return this.http
    //.post(`${environment.domainStageApi}WebTalkxType/InsertWebTalkxTypeDetails`, recObj).subscribe(res=>{
    .post(`${environment.domainStageApi}FinalSubmission/InsertFinalSubmissionDetails`, form.value).subscribe(res=>{
      let data = Object.keys(res).length;
      if (data && res[0]['ResponseStatus'] == 'Success') {
        this.step_one = false;
        //this.webTalkxtypeId = res[0]['WebTalkxTypeID'];
        //hiding loader after login
        this.appcmp.showLoader = false;
        
      }
    });
  }

  
  // Method to save the first step
  firstStepUpdate(form) {

    let recObj: any = {};
    recObj.WebTalkxType = this.selected_type_id;
    recObj.GroupRecording = this.recordingtype;
    recObj.AuthorID = this.UserID;

    if(this.hiringId) form.value.HiringID = this.hiringId;
    if(this.surveyid) form.value.SurveyID = this.surveyid;

    form.value.HiringWebTalkxTypeID = this.selected_type_id;
    form.value.ProjectName = form.value.HiringProjectName;
    form.value.JobDescription = this.jobdescription || form.value.descriptionfile;
    form.value.HiringStartDate = form.value.HiringStartDate || "2021-01-01";
    form.value.HiringEndDate = form.value.HiringEndDate || "2021-02-02";
    form.value.Organisation = form.value.HiringOrganization;
    form.value.Manager = form.value.HiringManager;
    form.value.HiringReviewTeamID = this.reviewteam_id || form.value.HiringReviewTeam;
    form.value.HiringRecordingLimitID = this.record_limitid || form.value.HiringRecordingLimit;
    form.value.HiringWelcomeMessage = form.value.WelcomeMessage;
    form.value.HiringDescription = form.value.Description;
    form.value.EmailID = form.value.HiringEmailId;
    form.value.FirstName = form.value.FirstName;
    form.value.LastName = form.value.LastName;
    form.value.PhoneNumber = form.value.PhoneNumber;
    form.value.LinkedIn = form.value.LinkedinProfileLink;
    form.value.Documents = this.candidatedoc || form.value.candidatedocument;
    form.value.SurveyID = this.surveyid;
    form.value.SurveyWebTalkxTypeID = this.selected_type_id;
    form.value.KeepSurveyAnonymous = form.value.IsSurveyAnonymous;
    form.value.SurveyStartDate = form.value.SurveyStartDate || "2021-01-01";
    form.value.SurveyEndDate = form.value.SurveyEndDate || "2021-01-02";
    form.value.SurveySubmissionLimitID = form.value.SubmissionLimit;
    form.value.SurveyTitle = form.value.SurveyTitle;
    form.value.SurveyWelcomeMessage = form.value.WelcomeMessage;
    form.value.SurveyDescription = form.value.Description;
    form.value.SponsorMessageRequired = form.value.IsIntroMessage;
    form.value.SurveyReviewTeamID = this.reviewteam_id || form.value.SurveyReviewTeam;
    form.value.SurveyIndividualRecordingLimitID = this.record_limitid || form.value.RecordingLimit;
    form.value.CustomWelcomePage = this.welcomepagename || form.value.CustomWelcome;
    form.value.CollectorType = this.collector_type;
    form.value.WelcomePageRequired = form.value.IsIntroMessage;
    form.value.FinalStatus = 'Draft';
    form.value.AuthorID = this.UserID;

    this.appcmp.showLoader = true;
    this.appcmp.loadermessage = 'Please wait, updating recording details...';
    
    return this.http
    //.post(`${environment.domainStageApi}WebTalkxType/UpdateWebTalkxTypeDetails`, recObj).subscribe(res=>{
    .post(`${environment.domainStageApi}FinalSubmission/InsertFinalSubmissionDetails`, form.value).subscribe(res=>{
      let data = Object.keys(res).length;
      if (data && res[0]['ResponseStatus'] == 'Success') {
        this.step_one = false;
        //this.webTalkxtypeId = res[0]['WebTalkxTypeID'];
        //hiding loader after login
        this.appcmp.showLoader = false;
        
      }
    });
  }
  
  // Method to save the first step
  secondStepSave(form) {

    let recObj: any = {};
    let formval = form;
    
    //Now inserting the other details
    this.insertAndUpdateFormData(formval, "N");
    
    if(this.webtalkxtype == 'Survey') {
     
      recObj.WebTalkxTypeID = this.selected_type_id;
      recObj.SurveyTitle = formval.value.SurveyTitle;
      recObj.KeepSurveyAnonymous = formval.value.IsSurveyAnonymous;
      recObj.SurveyStartDate = formval.value.SurveyStartDate;
      recObj.SurveyEndDate = formval.value.SurveyEndDate;
      recObj.SurveySubmissionLimitID = this.submission_limitid || formval.value.SubmissionLimit;
      recObj.WelcomeMessage = formval.value.WelcomeMessage;
      recObj.Description = formval.value.Description;
      recObj.SponsorMessageRequired = formval.value.IsIntroMessage;
      recObj.UploadLogo = this.logoname;
      recObj.SurveyReviewTeamID = formval.value.SurveyReviewTeam;
      recObj.CustomWelcomePage = this.welcomepagename;
      recObj.IndividualRecordingLimitID = this.record_limitid || formval.value.RecordingLimit;
      recObj.AuthorID = this.UserID;
      
      return this.http
      .post(`${environment.domainStageApi}Survey/InsertSurveyDetails`, recObj).subscribe(res=>{
        let data = Object.keys(res).length;
        if (data && res[0]['ResponseStatus'] == 'Success') {
          this.step_two = false;
          this.surveyid = res[0]['SurveyID'];
          
          //hiding loader after login
          //this.appcmp.showLoader = false;
          
        }
      });

    } else {
      recObj.WebTalkxTypeID = this.selected_type_id;
      recObj.ProjectName = formval.value.HiringProjectName;
      recObj.JobDescription = this.jobdescription;
      recObj.HiringStartDate = formval.value.HiringStartDate;
      recObj.HiringEndDate = formval.value.HiringEndDate;
      recObj.Organisation = formval.value.HiringOrganization;
      recObj.Manager = formval.value.Manager;
      recObj.ReviewTeamID = this.reviewteam_id || formval.value.HiringReviewTeam;
      recObj.RecordingLimitID = this.record_limitid || formval.value.HiringRecordingLimit;
      recObj.WelcomeMessage = formval.value.WelcomeMessage;
      recObj.Description = formval.value.Description;
      recObj.EmailID = formval.value.HiringEmailId;
      recObj.FirstName = formval.value.FirstName;
      recObj.LastName = formval.value.LastName;
      recObj.PhoneNumber = formval.value.PhoneNumber;
      recObj.LinkedIn = formval.value.LinkedinProfileLink;
      recObj.Documents = this.candidatedoc;
      recObj.SponsorMessageRequired = formval.value.IsIntroMessage;
      recObj.AuthorID = this.UserID;
      
      return this.http
      .post(`${environment.domainStageApi}Hiring/InsertHiringDetails`, recObj).subscribe(res=>{
        let data = Object.keys(res).length;
        if (data && res[0]['ResponseStatus'] == 'Success') {
          this.step_two = false;
          this.hiringId = res[0]['HiringID'];
          
          //Now inserting the other details
          //this.insertAndUpdateFormData(formval, "N");

          //hiding loader after login
          //this.appcmp.showLoader = false;
          
        }
      });

    }
    
    
  }

  //Method to update the steps
  secondStepUpdate(form) {
    
    let recObj: any = {};
    let formval = form;
    
    //Now inserting the other details
    this.insertAndUpdateFormData(formval, "Y");
    
    if(this.webtalkxtype == 'Survey') {
      
      recObj.WebTalkxTypeID = this.selected_type_id;
      recObj.SurveyID = this.surveyid;
      recObj.SurveyTitle = formval.value.SurveyTitle;
      recObj.KeepSurveyAnonymous = formval.value.IsSurveyAnonymous;
      recObj.SurveyStartDate = formval.value.SurveyStartDate;
      recObj.SurveyEndDate = formval.value.SurveyEndDate;
      recObj.SurveySubmissionLimitID = this.submission_limitid || formval.value.SubmissionLimit;
      recObj.WelcomeMessage = formval.value.WelcomeMessage;
      recObj.Description = formval.value.Description;
      recObj.SponsorMessageRequired = formval.value.IsIntroMessage;
      recObj.UploadLogo = this.logoname || formval.value.uploadlogo;
      recObj.SurveyReviewTeamID = this.reviewteam_id || formval.value.SurveyReviewTeam;
      recObj.CustomWelcomePage = this.welcomepagename;
      recObj.IndividualRecordingLimitID = this.record_limitid || formval.value.RecordingLimit;
      recObj.AuthorID = this.UserID;
      
      return this.http
      .put(`${environment.domainStageApi}Survey/UpdateSurveyDetails`, recObj).subscribe(res=>{
        let data = Object.keys(res).length;
        if (data && res[0]['ResponseStatus'] == 'Success') {
          this.step_two = false;

          //hiding loader after login
          this.appcmp.showLoader = false;
          
        }
      });

    } else {
      recObj.HiringID = this.hiringId;
      recObj.WebTalkxTypeID = this.selected_type_id;
      recObj.ProjectName = formval.value.HiringProjectName;
      recObj.Organisation = formval.value.HiringOrganization;
      recObj.JobDescription = this.jobdescription;
      recObj.HiringStartDate = formval.value.HiringStartDate;
      recObj.HiringEndDate = formval.value.HiringEndDate;
      recObj.HiringOrganization = formval.value.Organisation;
      recObj.Manager = formval.value.Manager;
      recObj.ReviewTeamID = this.reviewteam_id || formval.value.HiringReviewTeam;
      recObj.RecordingLimitID = this.record_limitid || formval.value.HiringRecordingLimit;
      recObj.WelcomeMessage = formval.value.WelcomeMessage;
      recObj.Description = formval.value.Description;
      recObj.EmailID = formval.value.HiringEmailId;
      recObj.FirstName = formval.value.FirstName;
      recObj.LastName = formval.value.LastName;
      recObj.PhoneNumber = formval.value.PhoneNumber;
      recObj.LinkedIn = formval.value.LinkedinProfileLink;
      recObj.Documents = this.candidatedoc;
      recObj.SponsorMessageRequired = formval.value.IsIntroMessage;
      recObj.AuthorID = this.UserID;   
      
      return this.http
      .put(`${environment.domainStageApi}Hiring/UpdateHiringDetails`, recObj).subscribe(res=>{
        let data = Object.keys(res).length;
        if (data && res[0]['ResponseStatus'] == 'Success') {
          this.step_two = false;
          //this.hiringId = res[0]['HiringID'];
          
          //Now inserting the other details
          //this.insertAndUpdateFormData(formval, "Y");

          //hiding loader after login
          this.appcmp.showLoader = false;
          
        }
      });

    }
  }
  
  // Method to save the first step
  fourthStepSave(model) {

    let recObj: any = {};
    
    recObj.CollectorType = this.collector_type;
    recObj.FirstName = 3;
    recObj.LastName = 2;
    recObj.Email = 1;
    recObj.PhoneNumber = 2;
    recObj.SocialMediaLink = 2;
    recObj.AuthorID = this.UserID;
    
    this.appcmp.showLoader = true;
    this.appcmp.loadermessage = 'Please wait, saving collector details...';
    
    return this.http
    .post(`${environment.domainStageApi}SurveyCollector/InsertSurveyCollectoreDetails`, recObj).subscribe(res=>{
      if (res[0]['ResponseStatus'] == 'Success') {
        this.step_four = false;
        this.collectorId = res[0]['SurveyCollectorID'];
        //hiding loader after login
        this.appcmp.showLoader = false;
        
      }
    });
  }
  
  // Method to save the first step
  fourthStepUpdate(model) {

    let recObj: any = {};
    
    recObj.SurveyCollectorID = this.collectorId;
    recObj.CollectorType = this.collector_type;
    recObj.FirstName = 3;
    recObj.LastName = 2;
    recObj.Email = 1;
    recObj.PhoneNumber = 2;
    recObj.SocialMediaLink = 2;
    recObj.AuthorID = this.UserID;
    
    this.appcmp.showLoader = true;
    this.appcmp.loadermessage = 'Please wait, updating collector details...';
    
    return this.http
    .put(`${environment.domainStageApi}SurveyCollector/UpdateSurveyCollectorDetails`, recObj).subscribe(res=>{
      if (res[0]['ResponseStatus'] == 'Success') {
        this.step_four = false;
        this.collectorId = res[0]['HiringID'];
        //hiding loader after login
        this.appcmp.showLoader = false;
        
      }
    });
  }

  //Method to select image to upload
  welcomePageUpload(e, file: FileList) {
    
    if (file) {
      this.documentToUpload = file.item(0);
      this.isdocumentUpload = true;
      this.welcomepagename = this.documentToUpload.name;
      //Show image preview
      let reader = new FileReader();
      reader.onload = (event: any) => {

    }
      reader.readAsDataURL(this.documentToUpload);
    }
  }
  
  //Method to select image to upload
  logoUpload(e, file: FileList) {
    
    if (file) {
      this.logoToUpload = file.item(0);
      this.isdocumentUpload = true;
      this.logoname = this.logoToUpload.name;
      //Show image preview
      let reader = new FileReader();
      reader.onload = (event: any) => {

    }
      reader.readAsDataURL(this.logoToUpload);
    }
  }
  
  //Method to select image to upload
  documentUpload(e, file: FileList) {
    
    if (file) {
      this.jobdescToUpload = file.item(0);
      this.isdocumentUpload = true;
      this.jobdescription = this.jobdescToUpload.name;
      //Show image preview
      let reader = new FileReader();
      reader.onload = (event: any) => {

    }
      reader.readAsDataURL(this.jobdescToUpload);
    }
  }
  
  //Method to select image to upload
  candidateDocumentUpload(e, file: FileList) {
    
    if (file) {
      this.candDocToUpload = file.item(0);
      this.isdocumentUpload = true;
      this.candidatedoc = this.candDocToUpload.name;
      //Show image preview
      let reader = new FileReader();
      reader.onload = (event: any) => {

    }
      reader.readAsDataURL(this.candDocToUpload);
    }
  }


  // Clear function for multi stepss form 
  clearForm(form, stepcount: number) {
    
    if (stepcount == 1) {
      this.model.HireRecording = null;
      this.model.ReferenceRecording = null;
      this.model.SurveyGroupRecording = null;
      this.model.GeneralRecording = null;

      //If group or project created on second step but we moved back and selected the different block then reset and allow to create new or select existing from dropdown
      this.surveyid = null;
      this.hiringId = null;
      this.step_two = true;
      this.step_one = true;

    } else if (stepcount == 2) {
            
      //If group or project created on second step but we moved back and selected the different block then reset and allow to create new or select existing from dropdown
      this.surveyid = null;
      this.hiringId = null;
      this.step_two = true;
      this.step_one = true;

      this.model = {
        SurveyTitle: null,
        KeepSurveyAnonymous: null,
        SurveyStartDate: null,
        SurveyEndDate: null,
        SurveySubmissionLimit: null,
        WelcomeMessage: null,
        Description: null,
        IsIntroMessage: null,
        UploadLogo: null,
        SurveyReviewTeam: null,
        CustomWelcomePage: null,
        IndividualRecordingLimit: null,
        HiringProjectName: null,
        JobDescription: null,
        HiringStartDate: null,
        HiringEndDate: null,
        HiringOrganization: null,
        Manager: null,
        HiringReviewTeam: null,
        HiringEmailId: null,
        FirstName: null,
        LastName: null,
        HiringRecordingLimit: null,
        PhoneNumber: null,
        LinkedinProfileLink: null,
        Documents: null
      }

      this.logoUpload = null;
      this.welcomepagename = null;
      this.surveyid = null;
      this.candidatedoc = null;
      this.jobdescription = null;
      this.hiringId = null;

    }
  }

  //Method to sort the list of question
  sortListQuestion() {

    if (this.finalizeSelectedQu.length > 0) this.finalizeSelectedQu = [];

    let selected_question = document.querySelectorAll('.selected_question');

    //this.startsort = true;
    if (selected_question.length > 0) {
      let value, obj, isDisabled;
      for (let i = 0; i < selected_question.length; i++) {
        /*if (selected_question[i] && (selected_question[i] as HTMLTextAreaElement).value && (selected_question[i] as HTMLTextAreaElement).value.trim()) {
          isDisabled = (selected_question[i] as HTMLTextAreaElement).hasAttribute('disabled');

          value = (selected_question[i] as HTMLTextAreaElement).value.trim();
          obj = {Value:value, IsDasbled: isDisabled};
            
          if (value || isDisabled) this.checkedListQuestion.push(obj);
          //value = (selected_question[i] as HTMLTextAreaElement).value.trim();
          //if (value) this.checkedListQuestion.push(value);
        }*/
        if (selected_question[i]) {
          isDisabled = (selected_question[i] as HTMLTextAreaElement).hasAttribute('disabled');
          if(isDisabled){
            obj = {Value:i+1, IsDasbled: isDisabled};
            
            this.finalizeSelectedQu.push(obj);
          } else if ((selected_question[i] as HTMLTextAreaElement).value && (selected_question[i] as HTMLTextAreaElement).value.trim()) {
            isDisabled = (selected_question[i] as HTMLTextAreaElement).hasAttribute('disabled');
            value = (selected_question[i] as HTMLTextAreaElement).value.trim();
            obj = {Value:value, IsDasbled: isDisabled};
            
            //if (value) this.finalizeSelectedQu.push(value);
            if (value || isDisabled) this.checkedListQuestion.push(obj);
          }
        }
      }
    }

    /*if (sort_question.length > 0) {
      let value;
      for (let i = 0; i < sort_question.length; i++) {
        if (sort_question[i] && (sort_question[i] as HTMLElement).innerText && (sort_question[i] as HTMLElement).innerText.trim()) {
          value = (sort_question[i] as HTMLElement).innerText.trim();
          if (value) this.checkedListQuestion.push(value);
        }
      }
    }*/
  }

  //Method to draw the selected question
  drawSelectedQuestion() {

    if (this.finalizeSelectedQu.length > 0) this.finalizeSelectedQu = [];

    let selected_question = document.querySelectorAll('.selected_question');
    let sort_question = document.querySelectorAll('.sort_question');

    if (this.checkedListQuestion.length > 0) {
      //if (this.checkedListQuestion.length > 0) this.checkedListQuestion = [];
      if (sort_question.length > 0) {
        let value;
        for (let i = 0; i < sort_question.length; i++) {
          if (sort_question[i] && (sort_question[i] as HTMLElement).innerText && (sort_question[i] as HTMLElement).innerText.trim()) {
            //var a = document.getElementsByClassName('question_2')[0];
            //console.log(a.hasAttribute('disabled'));
            value = (sort_question[i] as HTMLElement).innerText.trim();
            if (value) this.finalizeSelectedQu.push(value);
          }
        }
      }
      //this.finalizeSelectedQu.push(this.checkedListQuestion);
    } else {
      if (selected_question.length > 0) {
        let value, isDisabled, obj:any = {};
        for (let i = 0; i < selected_question.length; i++) {
          if (selected_question[i]) {
            isDisabled = (selected_question[i] as HTMLTextAreaElement).hasAttribute('disabled');
            if(isDisabled){
              obj = {Value:i+1, IsDasbled: isDisabled};
              
              this.finalizeSelectedQu.push(obj);
            } else if ((selected_question[i] as HTMLTextAreaElement).value && (selected_question[i] as HTMLTextAreaElement).value.trim()) {
              isDisabled = (selected_question[i] as HTMLTextAreaElement).hasAttribute('disabled');
              value = (selected_question[i] as HTMLTextAreaElement).value.trim();
              obj = {Value:value, IsDasbled: isDisabled};
              
              //if (value) this.finalizeSelectedQu.push(value);
              if (value || isDisabled) this.finalizeSelectedQu.push(obj);
            }
          }
        }
      }
    }
    console.log("finalizeSelectedQu", this.finalizeSelectedQu);
    /*if (sort_question.length > 0) {
      let value;
      for (let i = 0; i < sort_question.length; i++) {
        if (sort_question[i] && (sort_question[i] as HTMLElement).innerText && (sort_question[i] as HTMLElement).innerText.trim()) {
          value = (sort_question[i] as HTMLElement).innerText.trim();
          if (value) this.checkedListQuestion.push(value);
        }
      }
    }*/

  }

  //drop question method
  //onQuestionDrop(event: CdkDragDrop<string[]>) {
  //  /*moveItemInArray(this.finalizeSelectedQu, event.previousIndex, event.currentIndex);
  //  this.finalizeSelectedQu.forEach((question, index) => {
  //    question = index + 1;
  //  });*/
  //  moveItemInArray(this.checkedListQuestion, event.previousIndex, event.currentIndex);
  //  this.checkedListQuestion.forEach((question, index) => {
  //    question = index + 1;
  //  });
  //}


  //Method to save the selected question
  SaveSelectedQuestion(model, form: NgModel) {
    //this.saveDraft = true;
    this.onSubmit(form);
  }


  //Method to add the additional question field dynamically
  addQuestion(event) {
    event.preventDefault();

    // Finding total number of elements added
    let element = document.getElementsByClassName("element"), last_element;
    let total_element = element.length;
    //let dynamic_text = document.getElementById('Question_1');
    last_element = element[total_element - 1];
    /*if (total_element > 1) {
      last_element = (dynamic_text as HTMLElement).previousSibling;
    } else {
      last_element = dynamic_text;
    }*/

    /*if (this.lastid) {
      last_element = dynamic_text[dynamic_text.length - 1];
    } else {
      last_element = element[total_element - 1];
    }*/

    if (total_element == 0) {
      last_element = document.getElementsByClassName('more_que_cont')[0];
    }

    let addfields = document.getElementsByClassName("add_fields")[0];

    // last <div> with element class id
    //let lastid = last_element.getAttribute("id"), split_id, nextindex;
    let lastid, split_id, nextindex;
    if (last_element && !last_element.classList.contains('more_que_cont')) {
      lastid = last_element.getAttribute("id")
    } else {
      lastid = 'Question_0';
    }
    //this.lastid = last_element.getAttribute("id");
    //let split_id, nextindex;

    if (lastid) {
      split_id = lastid.split("_");
      nextindex = Number(split_id[1]) + 1;
    }

    if (total_element >= 9) {
      addfields.setAttribute("disabled", "true");
    }


    //Check maximum allowed input fields
    if (total_element < this.max_fields) {

      //add input field but check before container is available or not
      //last_element
      if (last_element) {
        //last_element.insertAdjacentHTML('afterend', "<div class='element' id='Question_" + nextindex + "'><input class='txtBoxBig col-md- ml-1 my-3 form-textbox-border add-more-question' type='text' name='Question_" + nextindex + "' id='Question_" + nextindex + "' placeholder='Please enter question...' style='width:96%;' /><button id='remove_" + nextindex + "' class='remove_field btn-danger remove-icon' style='margin-bottom:-4px;border-radius:4px;'>x</button></div>");
        //last_element.insertAdjacentHTML('afterend', "<div class='element extra_container my-3' style='display:flex;align-items: center;' id='Question_" + nextindex + "'><textarea class='txtBoxBig textbox-border form-group selected_question p-1 add_extra_question m-0 add-more-question' name='Question_" + nextindex + "' id='Question_" + nextindex + "' placeholder='Enter your question' style='width:90%;margin: 0px 15px !important;border: 1px solid #cccccc !important;'></textarea><button id='remove_" + nextindex + "' class='remove_field btn-danger remove-icon' style='margin-bottom:-4px;border-radius:4px;'>x</button></div>");
        //dynamic_text.insertAdjacentHTML('beforebegin', "<div class='element dynamic_text extra_container my-3' style='display:flex;align-items: center;' id='Question_" + nextindex + "'><textarea class='txtBoxBig textbox-border form-group selected_question p-1 add_extra_question m-0 add-more-question' name='Question_" + nextindex + "' id='Question_" + nextindex + "' placeholder='Enter your question' style='width:90%;margin: 0px 15px !important;border: 1px solid #cccccc !important;'></textarea><button type='button' id='remove_" + nextindex + "' class='remove_field btn-danger remove-icon' style='margin-bottom:-4px;border-radius:4px;'>x</button></div>");
        if (last_element && last_element.classList.contains('more_que_cont')) {
          last_element.innerHTML = "<div class='element dynamic_text extra_container my-3' style='display:flex;align-items: center;' id='Question_" + nextindex + "'><textarea class='txtBoxBig abc textbox-border form-group selected_question p-1 add_extra_question m-0 add-more-question' name='Question_" + nextindex + "' id='Question_" + nextindex + "' placeholder='Enter your question' style='width:90%;margin: 0px 15px !important;border: 1px solid #cccccc !important;'></textarea><button type='button' id='remove_" + nextindex + "' class='remove_field btn-danger remove-icon' style='margin-bottom:-4px;border-radius:4px;'>x</button></div>";
        } else {
          last_element.insertAdjacentHTML('afterend', "<div class='element dynamic_text extra_container my-3' style='display:flex;align-items: center;' id='Question_" + nextindex + "'><textarea class='txtBoxBig abc textbox-border form-group selected_question p-1 add_extra_question m-0 add-more-question' name='Question_" + nextindex + "' id='Question_" + nextindex + "' placeholder='Enter your question' style='width:90%;margin: 0px 15px !important;border: 1px solid #cccccc !important;'></textarea><button type='button' id='remove_" + nextindex + "' class='remove_field btn-danger remove-icon' style='margin-bottom:-4px;border-radius:4px;'>x</button></div>");
        }

        //last_element.insertBefore(newItem, last_element.childNodes[0]);
        let remove_el = document.getElementsByClassName('remove_field');
        //let addmorequestion = document.getElementsByClassName('abc');

        //Adding event hadler on cross icon
        /*for (let m = 0; m < addmorequestion.length; m++) {
          addmorequestion[m].addEventListener('blur', this.sortQuestion.bind(this));
        }*/

        //Adding event hadler on cross icon
        for (let m = 0; m < remove_el.length; m++) {
          remove_el[m].addEventListener('click', this.removeQuestionField.bind(this));
        }
      }
    }
  }

  //Method to remove the addition question field
  removeQuestionField(event) {
    let id = event.target.parentElement.id, deleteindex, split_id, target, q_id;
    let addfields = document.getElementsByClassName("add_fields")[0];
    addfields.removeAttribute("disabled");

    target = event.target;
    if (target) q_id = target.getAttribute('question_id');

    if (id) {
      split_id = id.split("_");
      deleteindex = split_id[1];
    }

    // Remove <div> with id
    let elementto_remove = document.getElementById("Question_" + deleteindex);
    //Method to remove the notes
    if (q_id) this.QuestionRemove(q_id)

    if (elementto_remove) elementto_remove.remove();

  }

  //Method to remove the text area
  removeTextAreaField(cls) {
    let deleteindex;

    if (cls) {
      deleteindex = cls;

      // Remove <div> with id
      let elementto_remove = document.getElementById("Question_" + deleteindex);
      if (elementto_remove) elementto_remove.remove();
    }
  }

  //Method to start sorting
  sortQuestion() {
    this.checkedListQuestion = [];
    //Now darw the selected question
    this.sortListQuestion();
  }

  //Method to get the recording list
  GetMyQuestions(rid) {

    if (rid) {
      let ReferenveObj: any = {};
      ReferenveObj.RefRecordingID = rid;
      
      return this.http
      .post(`${environment.domainApi}I2BRecordingRequest/GetRecordingRequestQuestions`, ReferenveObj).subscribe(res=>{
        if (res["length"] > 0) {
          this.question_length = res["length"];
          let add_fields = document.getElementsByClassName('add_fields')[0];

          if (res[0]['ResponseStatus'] == 'Success') {
            this.questionList = res;

            if (this.question_length > 0) {

              for (let i = 0; i < this.question_length; i++) {

                if (add_fields) {
                  (add_fields as HTMLButtonElement).click();

                  let selected_question = document.querySelectorAll('.selected_question');
                  let remove_icon = document.querySelectorAll('.remove-icon');

                  if (selected_question[i]) {
                    if (selected_question[i].nodeName == 'TEXTAREA') {
                      //console.log((selected_question[j] as HTMLTextAreaElement).value);
                      selected_question[i].setAttribute('question_id', res[i]['RecordingQuestionID']);
                      remove_icon[i].setAttribute('question_id', res[i]['RecordingQuestionID']);
                      (selected_question[i] as HTMLTextAreaElement).value = res[i]['QuestionText'];

                    }
                  }
                }
              }
            } else {

              if (add_fields) {
                (add_fields as HTMLButtonElement).click();
                (add_fields as HTMLButtonElement).click();
              }
            }
          } else {

            if (add_fields) {
              (add_fields as HTMLButtonElement).click();
              (add_fields as HTMLButtonElement).click();
            }
          }
        }
      });

    }
  }

  //Method to get the recording list
  GetMySavedQuestionsByUser(getFav?) {

    let reqObj: any = {};
    reqObj.UserID = this.UserID;

    if (getFav) reqObj.MyFavorite = true;
    
    return this.http
    .post(`${environment.domainApi}I2BRecordingRequest/GetUserQuestionnare`, reqObj).subscribe(res=>{
      if (res["length"] > 0) {
        //this.question_length = res["length"];
        if (res[0]['ResponseStatus'] == 'Success') {

          this.SavedQuestionList = res;

          //Now getting those data which has my favorite is true
          let data_filter = this.SavedQuestionList.filter(element => element.MyFavorite == true)

          if (data_filter.length > 0) {
            this.favouriteQuestion = data_filter;
          } else {
            this.favouriteQuestion = [];
          }
          
          //Now initiating data table
          this.loadDataTable();
          
          //hiding loader
          //this.appcmp.showLoader = false;
        } else {

          this.SavedQuestionList = [];

          //hiding loader
          //this.appcmp.showLoader = false;
        }
      } else {
        this.SavedQuestionList = [];

        //hiding loader
        this.appcmp.showLoader = false;
      }
    });

  }

  //for update the profile.
  SelectMyFavoriteQuestion(q_id) {

    if (q_id) {
      const reqObj = { RecordingQuestionID: q_id };

      //showing loader icon
      this.appcmp.showLoader = true;
      this.appcmp.loadermessage = 'Please wait...';
      
      return this.http
      .put(`${environment.domainApi}I2BRecordingRequest/SelectMyFavoriteQuestion`, reqObj).subscribe(res=>{
        if (res[0]['ResponseStatus'] == 'Success') {
          this.GetMySavedQuestionsByUser(true);
          this.appcmp.showLoader = false;
        }
      });
      // this.dtOptions = {
      //   "order": [[2, "desc"]],
      // };
    }
  }

  //Method to set the dialog height as per the window height
  resizefilterDialog() {
    let w_height = window.innerHeight,
      resize_model = (document.getElementsByClassName('resize-model') as HTMLCollection),
      totalheight: number = 0;

    if (w_height && resize_model.length > 0) {

      totalheight = w_height * 90 / 100;
      for (let i = 0; i < resize_model.length; i++) {
        //Getting dialog element and setting the calculated height
        if (resize_model[i]) resize_model[i].setAttribute('style', 'height: ' + totalheight + 'px');
      }
    }
  }

  //Method to open/close the accordian menu 
  openCloseAccordianMenu(rotateicon) {

    if (rotateicon) {
      if (rotateicon.classList.contains('fa-angle-down')) {
        rotateicon.classList.remove('fa-angle-down');
        rotateicon.className += ' fa-angle-up';
      } else {
        rotateicon.classList.remove('fa-angle-up');
        rotateicon.className += ' fa-angle-down';
      }
    }
  }


  //Method to remove the notes
  QuestionRemove(id) {
    if (id) {
      let QuestionObj: any = {};
      QuestionObj.RecordingQuestionID = id;

      //hiding loader after login
      /*this.appcmp.showLoader = true;
      this.appcmp.loadermessage = "Question is being removed...";*/      

      return this.http
      .put(`${environment.domainApi}I2BRecordingRequest/DeleteQuestionFromUserQuestionnare`, QuestionObj).subscribe(res=>{
        if (res[0]['ResponseStatus'] == 'Success') {
          this.GetMySavedQuestionsByUser(true);
          this.appcmp.showLoader = false;
        }
      });
    }
  }

  getFavQuestion() {
    this.favouriteQuestion = this.SavedQuestionList.filter((value, index) => {
      return value.isChecked
    });
  }

  fetchCheckedIDs() {
    //this.checkedIDs = []
    this.SavedQuestionList.forEach((value, index) => {
      if (value.isChecked) {
        //this.checkedIDs.push(value.id);
        //console.log(this.checkedIDs)
      }
    });
  }

  changeSelection() {
    this.getFavQuestion();
  }

  //Method to fetch the User details by email id
  getUserByEmail(Email) {
    if (Email && Email.length > 3 && Email.indexOf('@') > -1) {
      return this.http
      .post(`${environment.domainApi}I2B_Users/GetUserDetailsByEmail`, Email).subscribe(res=>{
        if (res[0]['ResponseStatus'] == 'Success') {
          if (res && res["length"] > 0) {
            /*res.forEach(el => {
              if (el.EmailID === Email) {
                this.model.GiverFirstName = el.FirstName;
                this.model.GiverSecondName = el.LastName;
                this.model.GiverLinkedIn = el.LinkedIn;
              }
            });*/
          }
        }
      });
    } else {
      this.model.GiverFirstName = '';
      this.model.GiverSecondName = '';
      this.model.GiverLinkedIn = '';
    }
  }

  copyQuestionAcc(i, sampleInpt, elm) {
    var copyText = sampleInpt;

    /* Select the text field */
    copyText.focus();
    copyText.select();
    
    document.execCommand("copy");
    //this._notificationservice.success("Copied to Clipboard.");
  }

  //function is used for add/remove new more fields dynamically
  AddNewQuestions() {
    var max_fields_limit = 10;
    var q_index = 1;
    var min_limit = 0;
    var question_cont = document.getElementsByClassName('question_cont');

    if(question_cont && question_cont.length < 10) {
      var html = '', a = '40 sec', b = '60 sec', c = '90 sec', d = '120 sec';
      
      html += '<div class="input-group question_cont question_index_'+this.q_index+' mt-2">';
      html += '<div class="col-md-9 "><div class="form-group mb-1"><textarea class="form-control form-control-user font-13 resize-none selected_question question_'+this.q_index+'" id="question'+this.q_index+'" placeholder="Enter your question" name = "WelcomeMessage"></textarea></div></div>'
      html += '<div class="col-md-2"><div class="form-group"><select name="AnswerLimit" id="AnswerLimit" class="font-13 form-control AnswerLimit text-blue"><option class="text-blue font-weight-bold" value =" ' + a + ' "> ' + a + ' </option><option class="text-blue font-weight-bold"  value="' + b + '">' + b + '</option><option class="text-blue font-weight-bold"  value="' + c + '">' + c + '</option><option class="text-blue font-weight-bold"  value="' + d + '">' + d + '</option></select></div></div>';
      html += '<div class="col-md-1"><button type="button" name="remove" class="remove btn btn-sm p-0"><i class="fas fa-trash text-red border-0"></i></button></div>';
      html += '<div class="col-md-12"><div class="form-group"><div class="custom-control custom-checkbox d-flex"><input type="checkbox" class="custom-control-input RecordQuestion" index="'+this.q_index+'" id="RecordQuestion'+this.q_index+'"><label class="custom-control-label font-weight-bold" for="RecordQuestion'+this.q_index+'" name="RecordQuestion'+this.q_index+'">Record Question</label><div class="i-block card-dots-button catalog-info a ml-2" title="Click here to get more information."><i class="fa fa-info-circle btn_blue font-16"></i></div></div></div></div></div>'
        
      $('.row.question-section').append(html);
      this.q_index++;
    }
    
    const that = this;

    $(document).on('click', '.remove', function () {
      $(this).parent().parent().remove();
      that.toatalTimeCalculation();
    });

    
    $(document).on('change', '.RecordQuestion', function () {
      //console.log($(this).attr('index'));
      let index = $(this).attr('index');
      let check_val = $(this)[0].checked;
      console.log("index",index, check_val);
      //let video_btn = document.getElementsByClassName('vjs-device-button vjs-control')[0];
      //if(video_btn) (video_btn as HTMLButtonElement).click();

      that.enableRecordQuestion(index, check_val);
    });

    $(document).on('change', '.AnswerLimit', function () {
      that.toatalTimeCalculation();
    });

    that.toatalTimeCalculation();
  }

  ChangeValue(RecordingType, event) { }

  //Method to enable the recording question
  enableRecordQuestion(qindex, check_val){
    console.log(qindex, "checkbox");
    this.record_header = 'Record Question';

    var q_textarea = document.getElementsByClassName('question_'+qindex)[0];
    if(q_textarea) {
      if(check_val) {
        (q_textarea as HTMLTextAreaElement).value = '';
        q_textarea.setAttribute('disabled', String(check_val));
      }
      else q_textarea.removeAttribute('disabled');
    }
            
    //Added hack to open model to show the company details
    //(<any>$('#RecordingQuestionModal')).modal('show');

  }

  onRecordIntro($event){
    this.record_header = 'Record Introduction Message';
    let video_btn = document.getElementsByClassName('vjs-device-button vjs-control')[0];
    if(video_btn) (video_btn as HTMLButtonElement).click();
        
    //Added hack to open model to show the company details
    (<any>$('#RecordingQuestionModal')).modal('show');
  }

  
  //function is used for add/remove new more fields dynamically
  AddManualRow() {

    var html = '';
    
    html += '<div class="input-group row_entry_cont row_index_1 mt-2">';
    html += '<div class="col-md-2 "><div class="form-group mb-1"><input class="form-control form-control-user font-13 row_index_1" id="firstname_row" placeholder="First Name" name="FirstName"></div></div>'
    html += '<div class="col-md-2"><div class="form-group"><input class="form-control form-control-user font-13 row_index_1" id="lastname_row" placeholder="Last Name" name="LastName"></div></div>';
    html += '<div class="col-md-3"><div class="form-group"><input class="form-control form-control-user font-13 row_index_1" id="email_row" placeholder="Email Id" name="EmailId"></div></div>';
    html += '<div class="col-md-2"><div class="form-group"><input class="form-control form-control-user font-13 row_index_1" id="custom_row1" placeholder="Custom Field" name="CustomField1"></div></div>';
    html += '<div class="col-md-2"><div class="form-group"><input class="form-control form-control-user font-13 row_index_1" id="custom_row2" placeholder="Custom Field" name="CustomField2"></div></div>';
    html += '<div class="col-md-1"><button type="button" name="remove_row" class="remove_row btn btn-sm"><i class="fas fa-trash text-red border-0"></i></button></div></div>';
      
    $('.row.manual_entry_section').append(html);
    
    $(document).on('click', '.remove_row', function () {
      $(this).parent().parent().remove();
    });
  }

  //Method to delete the recording
  onDeleteRecording(e, index) {

  }

  //Method to reply the recording
  replayInterview(e, index){
    if(index) {
      let video_elm = document.getElementsByTagName('video')[0];
      let replay = document.getElementsByClassName('replay_'+index)[0];
      let ext;
      //console.log("elm", replay);
      if(video_elm) {
        if(replay) ext = replay.getAttribute('extension');
        video_elm.setAttribute('src', `https://sara.webtalkx.com/upload/request_`+this.recordingId+'_'+index+'.'+ext);
        video_elm.setAttribute('controls', 'controls');
      }
    }

  }

  //Method to init the selected items
  selectToInitRecording(index){
    //console.log(index);

    this.video_index = index;
    
    let start_btn = document.getElementsByClassName('start_intro')[0];
    if(start_btn) {      
      if(start_btn.classList.contains('-hidden')){
        start_btn.classList.remove('-hidden');
      }
    }
  }

  //Method to start the recording
  onStart(e) {
    
    let video_btn = document.getElementsByClassName('vjs-button vjs-icon-record-start')[0];
    if(video_btn) (video_btn as HTMLButtonElement).click();

    let video_elm = document.getElementsByTagName('video')[0];
    if(video_elm) video_elm.removeAttribute('controls');
    
    let start_btn = document.getElementsByClassName('start_intro')[0];
    if(start_btn) {
      //start_btn.setAttribute('disabled', 'true');
      
      if(!start_btn.classList.contains('-hidden')){
        start_btn.className += ' -hidden';
      }
    }

    let cancel_ans = document.querySelector('#btn-cancel-answer');
    let save_ans = document.querySelector('.btn-answer-question');

    if(cancel_ans && cancel_ans.classList.contains('-hidden')){
      cancel_ans.classList.remove('-hidden');
    }
    
    if(save_ans && save_ans.classList.contains('-hidden')){
      save_ans.classList.remove('-hidden');
    }
    this.IsRecordingStarted = true;
  }

  //Method to cancel the answer
  onCancelIntroduction() {
    this.IsRecordingStarted = false;
    this.IsRecordingCanceled = true;
    
    let video_btn = document.getElementsByClassName('vjs-device-button vjs-control')[0];
    //(video_btn as HTMLButtonElement).click();
    //this.ngAfterViewInit();
    
    let video_stop_btn = document.getElementsByClassName('vjs-control vjs-button vjs-icon-record-stop')[0];
    (video_stop_btn as HTMLButtonElement).click();
    
    let start_btn = document.getElementsByClassName('start_intro')[0];
    if(start_btn) {
      //start_btn.removeAttribute('disabled');
      if(start_btn && start_btn.classList.contains('-hidden')){
        start_btn.classList.remove('-hidden');
      }
    }
    
    let cancel_ans = document.querySelector('#btn-cancel-answer');
    let save_ans = document.querySelector('.btn-answer-question');

    if(cancel_ans && !cancel_ans.classList.contains('-hidden')){
      cancel_ans.className += ' -hidden';
    }
    
    if(save_ans && !save_ans.classList.contains('-hidden')){
      save_ans.className += ' -hidden';
    }
  }
    
  //method to count the skipped question
  saveIntroduction(e) {
    
    let video_stop_btn = document.getElementsByClassName('vjs-control vjs-button vjs-icon-record-stop')[0];
    if(video_stop_btn) (video_stop_btn as HTMLButtonElement).click();

    let video_btn = document.getElementsByClassName('vjs-device-button vjs-control')[0];
    //if(video_btn) (video_btn as HTMLButtonElement).click();
          
    let cancel_ans = document.querySelector('#btn-cancel-answer');
    let save_ans = document.querySelector('.btn-answer-question');
    
    let start_btn = document.getElementsByClassName('start_intro')[0];
    if(start_btn && !start_btn.classList.contains('-hidden')) {
      //start_btn.classList.remove('-hidden');
      start_btn.className += ' -hidden';
    }

    if(cancel_ans && !cancel_ans.classList.contains('-hidden')){
      cancel_ans.className += ' -hidden';
    }
    
    if(save_ans && !save_ans.classList.contains('-hidden')){
      save_ans.className += ' -hidden';
    }
    
    this.IsRecordingStarted = false;
    //Added hack to open model to show the company details
    (<any>$('#RecordingQuestionModal')).modal('hide');
    
  }

  //Method to close the model
  closeModal(){
    if(this.IsRecordingStarted) return false;
    //Added hack to open model to show the company details
    (<any>$('#RecordingQuestionModal')).modal('hide');
  }

  //method to calculate time and covert to total seconds into hours,minutes,second format
  toatalTimeCalculation() {
    let TimeValue:number=0, Ans_Limit, Welcome_Msg;

    Welcome_Msg = document.getElementsByClassName('WelcomeMessage');
    
    Ans_Limit = document.getElementsByClassName('AnswerLimit');

    //console.log(Ans_Limit);

    if (Ans_Limit.length > 0) {
      for (let i = 0; i < Ans_Limit.length; i++) {
       
        if (Ans_Limit[i]) {
          let val = Ans_Limit[i].value.replace("sec", "");
          //TimeValue += Number(Ans_Limit[i].value.replace("sec", ""));
          TimeValue += Number(val);
        }
        //console.log(TimeValue);
        if (TimeValue) {
          //we are converting time
          let totalSeconds = TimeValue;
          let hours = Math.floor(totalSeconds / 3600).toString();
          totalSeconds %= 3600;
          let minutes = Math.floor(totalSeconds / 60).toString();
          let seconds = (totalSeconds % 60).toString();

          //this is to add zero at the starting of time
          minutes = String(minutes).padStart(2, "0");
          hours = String(hours).padStart(2, "0");
          seconds = String(seconds).padStart(2, "0");
          this.TotalTime =  hours + ' : ' + minutes + ' : ' + seconds;

        } else {
         

        }


      }
    }
  }

  
  //methos to update time on Onchange
  updateAnswerTime(event,answerLimit) {
    let TimeValue: any = 0, target, AnswerLimitVal;

    if (event && event.target) target = event.target;
    //if (event) this.model.AnswerLimit = event.target.options[event.target.selectedIndex].value;
    //this.AnswerLimitVal = this.model.AnswerLimit.replace("sec", "");
   
    this.toatalTimeCalculation();

  }

  

}



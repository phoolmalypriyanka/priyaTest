import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-recordings-catalog-idid2',
  templateUrl: './recordings-catalog-idid2.component.html',
  styleUrls: ['./recordings-catalog-idid2.component.css']
})
export class RecordingsCatalogIDid2Component implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}

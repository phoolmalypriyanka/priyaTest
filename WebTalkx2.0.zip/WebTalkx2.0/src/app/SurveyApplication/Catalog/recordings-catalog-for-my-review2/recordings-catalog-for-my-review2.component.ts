import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-recordings-catalog-for-my-review2',
  templateUrl: './recordings-catalog-for-my-review2.component.html',
  styleUrls: ['./recordings-catalog-for-my-review2.component.css']
})
export class RecordingsCatalogForMyReview2Component implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}

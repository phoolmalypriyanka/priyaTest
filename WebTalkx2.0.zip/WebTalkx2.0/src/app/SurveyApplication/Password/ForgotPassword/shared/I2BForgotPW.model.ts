export class I2BForgotPWModel {
  Email?: string;
  UserID?: string;
  Password?: string;
  OldPassword?: string;
  AuthorID?: number;
}


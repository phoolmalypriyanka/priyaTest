export class recordingreviewmodel {
  RefRequestID: number;
  AuthorID: number;
  IsApproved: boolean;
  ApprovalDT: string;
  IsRejected: boolean;
  RejectionDT: string;
}

import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FormGroup, NgModel } from '@angular/forms';
import { Title } from '@angular/platform-browser';
import { AppComponent } from '../../../app.component';
import { GlobalVariable } from '../../../globals';
import { HttpErrorResponse } from '@angular/common/http';
import { SurveyApplicationComponent } from '../../SurveyApplication.component';
import { environment } from 'src/environments/environment';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-RequestedByMe',
  templateUrl: './RequestedByMe.component.html',
  styleUrls: ['./RequestedByMe.component.css']
})
export class RequestedByMeComponent implements OnInit {
  title: string;
  public show_dialog: boolean = false;
  public UserID: number;
  today: Date;
  model: any = {}
  form: FormGroup;
  recording_length: number;
  RecordingRequestList: any;
  masterSelected: boolean;
  checklist: any;
  checkedList: any;
  sender_id: number;
  receiver_id: number;
  full_name: string;

  RequesterFirstName: string;
  RequesterID: string;
  authername: string;
  autherID: string;
  GiverName: string;
  projectName: string;
  autheremail: string;
  startdate: string;
  enddate: string;
  GiverID: string;
  GiverLinkedIn: string;
  GiverEmailID: string;
  GiverFirstName: string;
  GiverSecondName: string;
  RequesterLastName: string;
  RecordingTitle: string;
  Instructions: string;
  RecordingStatus: string;
  catalog_record: any;
  askedbyemail: string;
  requestdate: string;
  requestfinishdate: string;
  RecordingObj: any;
  ReplayConsent: string;
  questionList;
  RequestTitle: string;
  RefRecordingID;
  webtakxtype:string = 'Hiring';

  constructor(private http: HttpClient, public surveyCmp: SurveyApplicationComponent, private router: Router, private titleService: Title, private appcmp: AppComponent) {
    //this.title = "Reference recordings | " + appcmp.title;
    this.title = appcmp.title + " | Requests By Me";
    if (localStorage.getItem('LoginUserID') == "" && localStorage.getItem('LoginUserID') == null) {
      this.router.navigateByUrl('/Login');
    }

    //Added window resize event and perform required operation
    window.onresize = (e) => {
      //Method to set the dialog height as per the window height
      this.resizefilterDialog();
    };

    this.appcmp.loadermessage = 'Please wait...';
    this.masterSelected = false;

    this.surveyCmp.showNavigation = true;
  }

  // Page init method
  ngOnInit() {
    //Added below line to remove the prompt message on reload and close browser.
    window.onbeforeunload = null;

    //Added below code to update the title
    this.titleService.setTitle(this.title);
    this.today = new Date();
    this.UserID = Number(localStorage.getItem('LoginUserID'));
    this.RefRecordingID = Number(localStorage.getItem('RefRecordingID'));
//    this.startSteps();

    //this.tour();

    //Method to set the dialog height as per the window height
    this.resizefilterDialog();

    //Method to get the recording list
    //this.takeinterviewservice.GetRefRequestDetails();
    this.GetReferenceRecording();
    
    this.sender_id = Number(localStorage.getItem('UserID'));

    //this.joyrideService.closeTour();
    this.model.WebtalkxType = 'Hiring';

  }
  
  // Method to load datatable js file.
  public loadDataTable() {
    let body = <HTMLDivElement>document.body;
    let script = document.createElement('script');
    script.innerHTML = '';
    script.src = 'assets/js/demo/datatables-demo.js';
    script.async = true;
    script.defer = true;
    body.appendChild(script);
  }
  
  //Method to select the webtalk type
  selectWebTalkType(type){
    this.webtakxtype = type;

    //Now updating the request list
    this.RecordingRequestList = [];
    this.GetReferenceRecording();
    
  }

  //Method to get the recording list
  GetReferenceRecording() {

    //showing loader
    this.appcmp.showLoader = true;
    this.appcmp.loadermessage = 'Loading requests...';

    let reqObj: any = {};
    reqObj.AuthorID = this.UserID;
    
    return this.http
    //.post(`${environment.domainApi}I2BRecordingRequest/GetRecordingRequest`, reqObj).subscribe(res=>{
      .get(`${environment.domainStageApi}FinalSubmission/GetFinalSubmissionWebTalkxDetails?AuthorID=` +  this.UserID + `&WebTalkxTypeName=` + this.webtakxtype).subscribe(res=>{
      
      if (res["length"] > 0) {
        this.recording_length = res["length"];
        
        if (res[0]['ResponseStatus'] == 'Success') {

          this.RecordingRequestList = res;
          //this.checklist = this.RecordingRequestList;

          let data_filter = this.RecordingRequestList.filter(element => element.FinalStatus.trim() == 'Open')

          if (data_filter.length > 0) {
            this.RecordingRequestList = data_filter;
            this.checklist = this.RecordingRequestList;

            //Now initiating datatable
            this.loadDataTable();
            
          } else {
            this.RecordingRequestList = [];
          }

          //hiding loader
          this.appcmp.showLoader = false;
        } else {
          this.RecordingRequestList = [];

          //hiding loader
          this.appcmp.showLoader = false;
        }
      } else {
        this.RecordingRequestList = [];

        //hiding loader
        this.appcmp.showLoader = false;
      }
    });

  }


  //Method to remove the recording requests
  removeRecordingRequest() {

    const recordObj = {
      ID: this.RecordingObj,
      AuthorID: this.UserID
    }

    this.appcmp.showLoader = true;
    this.appcmp.loadermessage = "Recording request is being removed...";
    
    //I2BRecordingRequest/DeleteRecordingRequest
    return this.http
    .put(`${environment.domainApi}FinalSubmission/DeleteFinalSubmissionWebTalkxDetails`, recordObj).subscribe(res=>{
      if (res[0]['ResponseStatus'] == 'Success') {

        //this._notificationservice.success("Recording request deleted successfully.");
        this.RecordingObj = null;

        //Now reload the grid
        this.GetReferenceRecording();

        //hidding loader icon
        this.appcmp.showLoader = false;
      }
    });

  }

  //Method to confirm delete
  deleteConfirm(rid) {
    this.RecordingObj = rid;
  }


  //Method to check and uncheck all recording
  checkUncheckAll() {
    for (let i = 0; i < this.checklist.length; i++) {
      this.checklist[i].isSelected = this.masterSelected;
    }
    this.getCheckedItemList();
  }

  //Method to check and uncheck single recording
  isAllSelected() {
    this.masterSelected = this.checklist.every(function (message: any) {
      return message.isSelected == true;
    })
    this.getCheckedItemList();
  }

  //Method to check and uncheck final object of recording
  getCheckedItemList() {
    this.checkedList = [];

    for (let i = 0; i < this.checklist.length; i++) {
      if (this.checklist[i].isSelected)
        this.checkedList.push(this.checklist[i]);
    }
    //this.checkedList = JSON.stringify(this.checkedList);

    //now enabling the delete icon if data is selected
    this.enableDisableDeleteIcon();
  }

  //Method to enable and disable the delete icon
  enableDisableDeleteIcon() {

    let deletebtn = document.getElementById('row-delete-btn');
    if (this.checkedList.length > 0) {
      if (deletebtn) deletebtn.removeAttribute('disabled');
    } else {
      if (deletebtn) deletebtn.setAttribute('disabled', 'true');
    }
  }

  //Method to check the selected recording delete
  archiveRecording() {
    let recordingid;
    if (this.checkedList.length > 0) {
      for (let recording of this.checkedList) {
        recordingid = recording['RefRequestID'];

        if (recording) {
          //hiding loader after login
          this.appcmp.showLoader = true;
          this.appcmp.loadermessage = 'Recording is being removed...';
          this._recordingDeleteConfirm(recording);
        }
      }
    }
  }

  //Method to remove the selected recording
  _recordingDeleteConfirm(recording) {

    //console.log("Removing Mes", msgid);
    //recording = JSON.stringify(recording);
    
    return this.http
    .put(`${environment.domainApi}ReferenceGiver/InsertReferenceGiver`, recording).subscribe(res=>{
      
      //Once service completed then drawing recording
      this.GetReferenceRecording();

      //hiding loader after login
      this.appcmp.showLoader = false;
      //this._notificationservice.success("Recording removed successfully...");
    });

  }
   
  //Method to select individual row
  getSelectedRowInfo(recordings, id, e) {

    let target = e.target, input_ele;
    e.preventDefault();
    e.stopPropagation();

    //Added hack to open model to show the company details
    (<any>$('#catalogdetailsmodel')).modal('show');

    let r_id = recordings['ID'];

    if (r_id == id) {

      //Now getting question
      this.getQuestion(id);

      this.catalog_record = recordings;
      this.authername = recordings['AuthorName'];
      this.autherID = recordings['AuthorID'];
      this.GiverID = recordings['GiverID'];
      this.GiverLinkedIn = recordings['LinkedIn'];
      if (this.GiverLinkedIn && (this.GiverLinkedIn.indexOf('https') == -1 || this.GiverLinkedIn.indexOf('http') == -1)) {
        this.GiverLinkedIn = 'https://' + this.GiverLinkedIn;
      }
      this.GiverEmailID = recordings['EmailID'];
      this.GiverName = recordings['GiverName'];
      this.projectName = recordings['ProjectName'];
      this.RecordingStatus = recordings['FinalStatus'];
      this.autheremail = recordings['AuthorEmailID'];
      this.startdate = recordings['HiringStartDate'];
      this.enddate = recordings['HiringEndDate'];

    }
  }

  //Method to get the user info like id, name
  getUserInfo(e, id, f_name) {
    e.preventDefault();
    e.stopPropagation();

    //Added hack to open model to show the company details
    //Here it is checking to the loggedIn user
    if (id != this.UserID) {
      (<any>$('#sendmsgmodel')).modal('show');
    } else {
      (<any>$('#messagenotification')).modal('show');
    }

    this.receiver_id = id;
    this.full_name = f_name;
  }

  //Method to send the message to the user
  sendMessage(senderid, receiverid, usertextmsg) {

    let value, content: any = {}, msgcontainer;
    //if (usertextmsg) value = usertextmsg.value;

    let msgtext_new = this.urlify(usertextmsg.trim());
    
    content.MessageText = msgtext_new;
    content.SenderID = senderid;
    content.ReceiverID = receiverid;

    //hiding loader after login
    this.appcmp.showLoader = true;
    this.appcmp.loadermessage = 'Message is being sent...';

    if (usertextmsg) {
      //console.log("content", content);
      
      return this.http
      .post(`${environment.domainApi}Messages/InsertMessages`, content).subscribe(res=>{
        
        this.model.usertextmsg = "";
        if (res[0]['ResponseStatus'] == 'Success') {

          //hiding loader after login
          this.appcmp.showLoader = false;
          this.appcmp.loadermessage = 'Please wait...';
          //this._notificationservice.success("Message has been sent successfully.");

        }
        else {
          //this._notificationservice.error("Current password is wrong.");
          //hiding loader after login
          this.appcmp.showLoader = false;
        }
      });
    }
  }

  //method to convert the text into link if available
  urlify(text) {
    var urlRegex = /(((https?:\/\/)|(www\.))[^\s]+)/g;
    //var urlRegex = /(https?:\/\/[^\s]+)/g;
    return text.replace(urlRegex, function (url, b, c) {
      var url2 = (c == 'www.') ? 'http://' + url : url;
      return '<a class="white-text" href="' + url2 + '" target="_blank">' + url + '</a>';
    })
  }

  //method to get the original request
  viewSelectedRequest(id) {

    if (id) {
      //localStorage.setItem('RefRecordingID', id);
      this.router.navigateByUrl('/I2BApplication/RecordingRequest/' + id);
    }
  }

  //method to get the all the question
  getQuestion(rid) {
    //this.RefRequestID
    if (rid) {
      let ReferenveObj: any = {};
      ReferenveObj.RefRecordingID = rid;
      
      return this.http
      .post(`${environment.domainApi}I2BRecordingRequest/GetRecordingRequestQuestions`, ReferenveObj).subscribe(res=>{
        
        if (res["length"] > 0) {
          
          if (res[0]['ResponseStatus'] == 'Success') {
            this.questionList = res;
          } else {
            this.questionList = [];
          }
        } else {
          this.questionList = [];
        }
      });

    }
  }

  //Method to set the dialog height as per the window height
  resizefilterDialog() {
    let w_height = window.innerHeight,
      resize_model = (document.getElementsByClassName('resize-model') as HTMLCollection),
      totalheight: number = 0;

    if (w_height && resize_model.length > 0) {

      totalheight = w_height * 90 / 100;
      for (let i = 0; i < resize_model.length; i++) {
        //Getting dialog element and setting the calculated height
        if (resize_model[i]) resize_model[i].setAttribute('style', 'height: ' + totalheight + 'px');
      }
    }
  }

  copyQuestionAcc(i, sampleInpt, elm) {
    //debugger;
    var copyText = sampleInpt;

    /* Select the text field */
    copyText.focus();
    copyText.select();

    document.execCommand("copy");
    //this._notificationservice.success("Copied to Clipboard.");
  }
  
  //Method to select the webtalkx type
  selectWebtalkxType(element, type) {
    let webtalkx_type = document.getElementsByClassName('webtalkx_type');
    
    if(webtalkx_type) {
      for(let i = 0; i < webtalkx_type.length; i++){
        if(webtalkx_type[i] && webtalkx_type[i].classList.contains('active-block')) {
          webtalkx_type[i].classList.remove('active-block');
          webtalkx_type[i].classList.remove('bg-blue');
        }
      }
    }
    if(element && !element.classList.contains('active-block')) element.className += ' active-block bg-blue';

  }

}

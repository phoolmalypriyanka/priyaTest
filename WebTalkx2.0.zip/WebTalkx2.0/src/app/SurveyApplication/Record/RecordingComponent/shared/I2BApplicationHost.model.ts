export class I2BApplicationHostmodel {  
  RefRequestID: number;
  AuthorID: number;
  ArchiveID: string;
  URL: string;
}

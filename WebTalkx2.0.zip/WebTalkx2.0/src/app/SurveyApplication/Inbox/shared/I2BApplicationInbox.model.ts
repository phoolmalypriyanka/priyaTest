export class I2BApplicationInboxModel {
  //userid: number;
}

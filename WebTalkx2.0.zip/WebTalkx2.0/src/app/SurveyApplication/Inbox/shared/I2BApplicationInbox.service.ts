import { Injectable } from '@angular/core';
//import { Observable } from 'rxjs/Rx';
//import 'rxjs/add/operator/map';
//import 'rxjs/add/operator/toPromise';
import { HttpClient } from '@angular/common/http';
import { GlobalVariable } from '../../../globals';


@Injectable()
export class I2BApplicationInboxService {

  constructor() { }

}

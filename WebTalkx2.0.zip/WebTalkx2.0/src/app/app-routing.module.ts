import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { LoginComponent } from './Login/login.component';
import { SurveyApplicationComponent } from './SurveyApplication/SurveyApplication.component';
import { SurveyStartComponent } from './SurveyApplication/survey-start/survey-start.component';
import { SurveyRecordComponent } from './SurveyApplication/survey-record/survey-record.component';
import { SurveyCompleteComponent } from './SurveyApplication/survey-complete/survey-complete.component';
import { IntroVideoComponent } from './SurveyApplication/intro-video/intro-video.component';

import { DashboardComponent } from './SurveyApplication/Dashboard/Dashboard.component';
import { RecordingRequestComponent } from './SurveyApplication/Ask/RecordingRequest/RecordingRequest.component';
import { RecordingComponent } from './SurveyApplication/Record/RecordingComponent/RecordingComponent.component';
import { RequestedByMeComponent } from './SurveyApplication/Record/RequestedByMe/RequestedByMe.component';
import { RecordingsCatalogIRequestedComponent } from './SurveyApplication/Catalog/RecordingsCatalogIRequested/RecordingsCatalogIRequested.component';
import { InboxComponent } from './SurveyApplication/Inbox/Inbox.component';
import { RecordingReviewComponent } from './SurveyApplication/RecordingReview/RecordingReview';
import { ChangePasswordComponent } from './SurveyApplication/Password/ChangePassword/ChangePassword.component';

import { RequestsFromMeComponent } from './SurveyApplication/Record/RequestsFromMe/RequestsFromMe.component';
import { RecordingsCatalogIDidComponent } from './SurveyApplication/Catalog/RecordingsCatalogIDid/RecordingsCatalogIDid.component';
import { RecordingsCatalogForMyReviewComponent } from './SurveyApplication/Catalog/RecordingsCatalogForMyReview/RecordingsCatalogForMyReview.component';
import { MyQuestionsComponent } from './SurveyApplication/Ask/MyQuestions/MyQuestions.component';
import { SavedRequestsComponent } from './SurveyApplication/Ask/SavedRequests/SavedRequests.component';
import { EditProfileComponent } from './SurveyApplication/EditProfile/EditProfile.component';

import { ConfirmationCodeComponent } from './SurveyApplication/Password/ConfirmationCode/ConfirmationCode.component';
import { ForgotPasswordComponent } from './SurveyApplication/Password/ForgotPassword/ForgotPassword.component';

import { RegistMsgComponent } from './RegistMsg/RegistMsg.component';
import { SecureURLComponent } from './SecureUrl/SecureUrl.component';
import { TeamMembersComponent } from './SurveyApplication/TeamMembers/TeamMembers.component';
import { ResetPasswordComponent } from './SurveyApplication/Password/ResetPassword/ResetPassword.component';

import { FeedbackResponseComponent } from './FeedbackResponse/FeedbackResponse.component';
import { SignUpComponent } from './sign-up/sign-up.component';
import { RecordingsCatalogTestComponent } from './SurveyApplication/Catalog/recordings-catalog-test/recordings-catalog-test.component';

import { RecordingsCatalogIRequested2Component } from './SurveyApplication/Catalog/recordings-catalog-irequested2/recordings-catalog-irequested2.component';
import { RecordingsCatalogIDid2Component } from './SurveyApplication/Catalog/recordings-catalog-idid2/recordings-catalog-idid2.component';
import { RecordingsCatalogForMyReview2Component } from './SurveyApplication/Catalog/recordings-catalog-for-my-review2/recordings-catalog-for-my-review2.component';

const routes: Routes = [
  //{ path: 'SurveyApp/Start', component: SurveyStartComponent, pathMatch: 'full' },  
  //{ path: '*', component: SurveyStartComponent },
  //{ path: '', redirectTo: '/SurveyApp/Start', pathMatch: 'full' },
  /*{ path: 'SurveyApp/Completed', component: SurveyCompleteComponent },
  { path: 'SurveyApp/Record', component: SurveyRecordComponent },*/
  /*{
    path: '**', component: LoginComponent
  },*/
  { path: 'Login', component: LoginComponent },
  { path: '', redirectTo: '/Login', pathMatch: 'full' },
  { path: 'Login/:Userid', component: LoginComponent },
  { path: 'Login/:Userid/:Requestid', component: LoginComponent },
  { path: 'Login/:Userid/:Requestid/:Type', component: LoginComponent },
  { path: 'Signup', component: SignUpComponent },
  { path: 'Signup/:Userid', component: SignUpComponent },
  { path: 'Signup/:Userid/:Requestid', component: SignUpComponent },
  { path: 'Signup/:Userid/:Requestid/:Type', component: SignUpComponent },
  { path: 'SignupSuccess', component: RegistMsgComponent },
  { path: 'I2Breview/2r9QUFD/:id', component: SecureURLComponent, pathMatch: 'full' },
  { path: 'ForgotPassword', component: ForgotPasswordComponent, pathMatch: 'full' },
  { path: 'ResetPasswordCode/:id', component: ConfirmationCodeComponent, pathMatch: 'full' },
  { path: 'ResetPassword', component: ResetPasswordComponent, pathMatch: 'full' },
  { path: 'ConfirmationCode/:id', component: ConfirmationCodeComponent },
  {
    path: 'SurveyApp',
    component: SurveyApplicationComponent,
    children: [
      { path: 'Start', component: SurveyStartComponent },
      { path: 'Dashboard', component: DashboardComponent},
       { path: 'Record', component: SurveyRecordComponent},
       { path: 'Completed', component: SurveyCompleteComponent},
      { path: 'StartIntro', component: IntroVideoComponent }
    ]
  },
  {
    path: 'I2BApplication',
    component: SurveyApplicationComponent,
    children: [
      { path: 'RecordingRequest', component: RecordingRequestComponent },
      { path: 'RecordingRequest/:id', component: RecordingRequestComponent },
      { path: 'Dashboard', component: DashboardComponent },
      { path: 'RequestsByMe', component: RequestedByMeComponent },
      { path: 'RequestsFromMe', component: RequestsFromMeComponent },
      { path: 'MyNetwork', component: TeamMembersComponent },
      { path: 'Inbox', component: InboxComponent },
      { path: 'RecordingsCatalogByMe', component: RecordingsCatalogIRequestedComponent },
      { path: 'RecordingsCatalogFromMe', component: RecordingsCatalogIDidComponent },
      { path: 'RecordingsCatalogForMyReview', component: RecordingsCatalogForMyReviewComponent },
      { path: 'RecordingsCatalogForTest', component: RecordingsCatalogTestComponent },
      { path: 'I2BHost', component: RecordingComponent },
      { path: 'RecordingReview', component: RecordingReviewComponent },
      { path: 'MyQuestions', component: MyQuestionsComponent },
      { path: 'ChangePassword', component: ChangePasswordComponent },
      { path: 'SavedRequests', component: SavedRequestsComponent },
      { path: 'EditProfile', component: EditProfileComponent },
      { path: 'Feedback', component: FeedbackResponseComponent },
      { path: 'RecordingsCatalogByMe2', component: RecordingsCatalogIRequested2Component },
      { path: 'RecordingsCatalogFromMe2', component: RecordingsCatalogIDid2Component },
      { path: 'RecordingsCatalogForMyReview2', component: RecordingsCatalogForMyReview2Component },

    ]
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }

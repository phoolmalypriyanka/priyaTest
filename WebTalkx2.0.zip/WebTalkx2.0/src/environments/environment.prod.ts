export const environment = {
  production: true,
  //api:'https://71.185.249.62:8080/'
  //api:'http://localhost:8080/',
  /*api:'https://testlinuxvmcardnmore.ignatiuz.com/',
  q_api:'https://platform.webtalkx.com/api/',
  domainApi:'https://platform.webtalkx.com/api/',
  domainStageApi: 'https://stage.webtalkx.com/api'*/
  api:'https://sara.webtalkx.com/api/',
  q_api:'https://stage.webtalkx.com/api/',
  domainApi:'https://stage.webtalkx.com/api/',
  domainStageApi: 'https://stage.webtalkx.com/api/',
  videoapi:'https://sara.webtalkx.com/'
};
